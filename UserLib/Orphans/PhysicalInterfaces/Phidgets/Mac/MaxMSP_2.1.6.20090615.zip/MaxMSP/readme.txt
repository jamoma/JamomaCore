Max/MSP Externals for Phidgets
October 16, 2008
--------------------------------------------------------------------------
Installation:
Copy the externals you want to use to any location that is on the
search path specified by Max/MSP in Options->File Preferences...
--------------------------------------------------------------------------
Compatibility:
Requires Max/MSP 4.5 or higher
Requires Phidget library 2.1.4 or higher (phidget21)
Requires MacOS X 10.4 or higher
--------------------------------------------------------------------------
Usage:
Specific usage can be seen in the included patcher help files (.help)

Generally, all extensions have these options:
  getVersion, getSerial, getStatus

You don't need to have a phidget plugged in when you create your device and you can plug/unplug as many times as you like while it is initialized.

Reading is controllable in various ways, including at internal timer.

All device externals take an optional parameter to specify serial number - this needs to be specified when using more then one of a particular type of Phidget at a time.