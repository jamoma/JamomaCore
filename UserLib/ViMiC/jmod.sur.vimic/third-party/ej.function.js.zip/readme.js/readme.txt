ej.function, as part of ejies by Emmanuel Jourdan has to be installed from:
http://www.e--j.com/