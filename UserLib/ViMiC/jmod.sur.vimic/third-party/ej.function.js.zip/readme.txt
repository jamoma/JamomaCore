ej.function by Emmanuel Jourdan:
http://www.e--j.com/