/*************************/

/* Copyright 1988 IRCAM. */

/*************************/



#ifndef _EDIT_H_

#define _EDIT_H_



// information moved to ext_maxtypes.h



#endif /* _EDIT_H_ */



