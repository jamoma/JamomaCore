#ifndef __EXT_USER
#define __EXT_USER

// information moved to ext_maxtypes.h

#endif

