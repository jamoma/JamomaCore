#ifndef _EXT_MIDI_H_
#define _EXT_MIDI_H_

// this function is no longer supported

void midiinfo(void *mr);

#endif /* _EXT_MIDI_H_ */
