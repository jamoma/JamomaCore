Phidgets for MacOS X
Version 1.0.6
March 9th, 2006
--------------------------------------------------------------------------
Installation:
Run the Phidgets.mpkg package installer to install both the Kernel Driver, the Framework, the JNI library, and the Phidget Server, or you can install them seperately with thier own installers.

The Kernel extension Phidget.kext is installed into /System/Library/Extensions
The Framework Phidget20.framework is installed into /Library/Frameworks
The JNI Library libphidget20.jnilib is installed into /System/Library/Frameworks/JavaVM.Framework/Libraries
The Phidget WebService is installed into /usr/bin

NOTE that the framework has been moved from /System/Library/Frameworks to /Library/Frameworks
NOTE that the library has been changed from C++ to C linkage, so you can actually link to it from c source files (as well as c++)

Once these are installed, any programs built agaisnt the framework will run for any user on the system.
--------------------------------------------------------------------------
Compatibility:
MacOS X 10.3.9 and higher
Distribution is in the form of Universal Binaries in order to support Intel based Macs.
--------------------------------------------------------------------------
Usage:
The framework is basically just a dynamic shared library. The easiest way to use it is to create an xcode project and add the Phidget20 framework, then in your sourcecode you just have to define top level header:

	#include <CoreFoundation/CoreFoundation.h>
	#include <Phidget20/phidget20.h>

CoreFoundation has to be included before Phidget20.

In order for the xcode project to find Phidget20.h, you have to add /Library/Frameworks to the frameworks search path for that projects

All functionality is the same as the windows library, except for the Phidget Manager, which has been redesigned to use notifications rather then polling. You should therefore be able to compile the Windows example with very little tweaking.

Another change is that Phidgets can only be opened exclusively (if you open a phidget anywhere and then try to open it again in another program, it will fail). Therefore the exclusive parameter for opening devices is ignored.

To set up notifications a new function has been added:

	int CPhidgetManager_setupNotifications (CPhidgetManagerHandle phid, CFRunLoopRef runloop);

The esiest way to use this is:

	CPhidgetManager_setupNotifications(phidlist, CFRunLoopGetCurrent());
	CFRunLoopRun();

What this does is add attach and detach notifications for all Phidgets to your main run loop and then start that run loop. You can use the PhidgetManager_set_AttachHandler CPhidgetManager_set_DetachHandler functions to get callbacks when these happen.

Because of these notifictions, CPhidgetManager_poll should never need to be called (as it is in windows).

phidlist is a CPhidgetManagerInfo structure that will get updated automatically when devices are added and removed. See the example for more details.

The included examples are in XCode 2.2 format. If you can't open the project files, you probably need to upgrade, or you can create your own project and just add the sources. There are Cocoa examples for every device and one command line example. The cocoa built tools are included in the base examples folder.

There is also an included tool for setting tags, which are nonvolatile strings that can be set on the newest (soon to be available) phidgets. Each device has room for one 10 character string, which can be used to identify a device, or set of devices, rather then using serial numbers (or for any other purpose you like). The function for setting this string is not exposed, and the tool's source code not distributed, because setting the tag should not normally be done in a user program, as it will wear out the flash.

Since this library is a port of the Windows version, the windows VC++ examples will run with little to no modification. Also, since the JNI library is installed, the java examples will just work, without any modification.

--------------------------------------------------------------------------
Phidget WebService:

The Phidget WebService is a new tool, which along with the new library will allow you to open remote Phidgets. More details are available in the general documentation on the web site.

To run, start phidgetwebservice with at least a password. Run it with no options to see your options.

Some examples for the webservice have been included in the examples folder with a NET extension. The NET version on the Phidget Manager is a usefull tool for finding all servers on a local network running under a certain port, and listing the devices on each server. have a look at the source to see how it's done.