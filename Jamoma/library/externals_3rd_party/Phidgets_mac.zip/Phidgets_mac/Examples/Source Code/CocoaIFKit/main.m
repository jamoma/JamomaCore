//
//  main.m
//  CocoaIFKit
//
//  Created by Patrick McNeil on 22/07/05.
//  Copyright Phidgets Inc. 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
