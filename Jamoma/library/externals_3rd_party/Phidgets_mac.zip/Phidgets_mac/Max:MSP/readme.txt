Max/MSP Externals for Phidgets
January 20, 2006
--------------------------------------------------------------------------
Installation:
Just copy the externals you want to use to any location that is on the
search path specified by Max/MSP in Options->File Preferences...
--------------------------------------------------------------------------
Compatibility:
Requires Max/MSP 4.5 or higher
Requires Phidget library 1.0.6 or higher
--------------------------------------------------------------------------
Usage:
Specific usage can be seen in the included patcher files (.help)

Generally, all extensions have these options:
  reconnect - for attaching a phidget after the extension is loaded
  getVersion, getSerial, getStatus

Reading is controllable in various ways, including at internal timer.

Also, they can all take in an optional parameter to specify a serial 
number.

The source code has been included for debugging/expanding as you like