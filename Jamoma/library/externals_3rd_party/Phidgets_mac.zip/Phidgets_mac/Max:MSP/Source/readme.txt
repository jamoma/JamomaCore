Phidget21 Max externals source

This is the source for the Phidgets externals.
Requires: Phidget21, Max 4.6 Universal Binary SDK, MacOS X 10.4
