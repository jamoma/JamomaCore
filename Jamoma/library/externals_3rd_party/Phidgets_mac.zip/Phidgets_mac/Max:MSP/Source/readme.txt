these examples show very simply how to write MAX externals for Phidgets, in Xcode. For general info on setting up the build settings properly in xcode see "machodev-readme.txt" in the "Mach-O Development" folder of the MAX/MSP SDK, or you can just start with this project.

This requires the Phidget20 framework to be installed and included (available from www.phidgets.com).