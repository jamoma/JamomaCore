#ifndef _EXT_MENU_H_
#define _EXT_MENU_H_

// t_menuinfo struct definition moved to ext_maxtypes.h

#endif /* _EXT_MENU_H_ */