#ifndef TT_TARGET_MAX
#define TT_TARGET_MAX 1
#endif

#ifdef __MWERKS__
#include "MacHeadersCarbon.h"
#endif

