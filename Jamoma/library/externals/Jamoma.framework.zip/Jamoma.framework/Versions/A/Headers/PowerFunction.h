/* 
 * Jamoma FunctionLib: PowerFunction
 * Copyright © 2007
 * 
 * License: This code is licensed under the terms of the GNU LGPL
 * http://www.gnu.org/licenses/lgpl.html 
 */

#ifndef __POWERFUNCTION_H__
#define __POWERFUNCTION_H__

#include "FunctionLib.h"


/****************************************************************************************************/
// Class Specification


// Specification of our base class
class PowerFunction : FunctionLib{
	public:
		PowerFunction();
		~PowerFunction();
		
		double mapValue(double x);
		// double lookupValue(double x);

		/** Default mode for symmetry is "none" */
		JamomaError setParameter(t_symbol *parameterName, long argc, t_atom *argv);

		/** This memory needs to be freed by the method calling this one */
		JamomaError getParameter(t_symbol *parameterName, long *argc, t_atom **argv);

		/** This memory needs to be freed by the method calling this one */
		JamomaError getFunctionParameters(long *argc, t_atom **argv);
		
	private:

		// ATTRIBUTES and internal coefficients		
		double powerValue;					///< Parameter for function: y pow(x,pow(2,powerValue))	
		double k;							///< k = pow(2,powerValue)
		t_symbol *symmetryMode;				///< Mode: none, point or axis
};


#endif // __POWERFUNCTION_H__
