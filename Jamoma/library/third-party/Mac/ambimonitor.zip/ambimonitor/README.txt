Update: New version from Philippe March 3 2009

----------------------------ICST Ambisonics Tools 2.0

----------------------------

AMBIMONITOR for Max5

Alpha Version 4
Release 2009 02 04----------------------------
This external is still under construction. New functions are not documented yet, some of the old functions are not implemented yet. Check regularly for updates on http://www.icst.net/downloads/beta/


NEW:

- the message "size" has been removed (use the attribute "patching rectangle" / "presentation rectangle")
- the number range of the D - coordinate is now 0.0 - 1.0

- lock points (L on the keyboard)
- group points (message "group <group no> <point-1 point-2 ... point-n>" or G, G+shift on the keyboard)
- "inspector" dialog box (doubleclick)
- zoom available in all three modes
- background / point images
- orientation


STILL MISSING:

- read/load files
- a help file...
----------------------------
When loading an Max4.x patcher, the properties of the ambimonitor object (position, settings, colors) should now be restored.

For the time being, the ambimonitor does not appear in Max' object palette. To instatiate it, type "ambimonitor" in a new object box.
----------------------------The ICST Ambisonics Tools have been developed at the Institute for Computer Music and Sound Technology of the Zurich University of the Arts

- Philippe Kocher- Jan Schacher----------------------------