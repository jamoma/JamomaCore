/* 

	snapshots.c		store and recall snapshots, write to / read from a XML file
					part of the ICST Ambisonics Tools
	
	Copyright (C) 2005 - 2006 ICST Zurich / Philippe Kocher
	
	http://www.icst.net
	

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
	
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
	
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	
	
	2006/06/18 Version 1.1	ported to PC
	2006/03/27 Version 1.0	initial release

*/

#include "ambimonitor.h"


// prototypes

void *get_snapshot_by_index(snapshot *pointer, char *name);
void monitor_snapshot_remove(t_monitor *x, snapshot *pointer);
void monitor_snapshot_link(t_monitor *x, snapshot *pointer);

short read_ambiscore(t_monitor *x, t_filehandle file);
short read_snapshot(t_monitor *x, t_filehandle file, char* attr_val);
short read_point(t_filehandle file, ambi* coord);

short file_getchar(t_filehandle file, char *c);
short string_to_number(char *str);
void string_to_triplet(char *str, double *coord_triplet);
short white_space(char c);
void remove_space_from_string(char *str);

short get_tag(t_filehandle file, char *tag, char *rem);
short get_attr_value_pair(char *buf, char *attr, char *val, char *rem);
short get_data(t_filehandle file, char *data);


//___________________________________________________________________________________________________________________________

// store snapshots

void monitor_store(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	snapshot  *pointer, *new_pointer;
	short i,j;
	short num_of_points;
	char index[64];
	short size;
			
	// count points on monitor
	for(i=0,num_of_points=0;i<MAXPOINTS;i++)
		if(x->coord[i].status != 0) num_of_points++;
		
	// ... empty screen
	if(num_of_points == 0)
		return;
	
	// bad arguments
	if(ac > 1)
		return;
		
	// allocate memory
	size = sizeof(snapshot) + (num_of_points - 1) * sizeof(coords);
	new_pointer = (snapshot *)sysmem_newptr(size);

	switch(av[0].a_type)
	{
		case A_LONG:
			sprintf(index, "%ld", av[0].a_w.w_long);
			break;
		case A_SYM:
			strcpy(index, (char *)av[0].a_w.w_sym->s_name);
			break;
		default: return;
	}
	
	// check if snapshot already exists	
	pointer = get_snapshot_by_index(x->first_snapshot, index);
	if(pointer)
		monitor_snapshot_remove(x, pointer);
	
	// write index
	new_pointer->index = sysmem_newptr(sizeof(index));
	strcpy(new_pointer->index, index);
	
	// build linked list
	monitor_snapshot_link(x, new_pointer);
			
	// write data
	new_pointer->num_of_points = num_of_points;
	new_pointer->time = new_pointer->mode = -1;
	
	for(i=0,j=0;i<MAXPOINTS;i++)
	{
		if(x->coord[i].status != 0)
		{
			new_pointer->data[j].number = i + 1;
			sysmem_copyptr(&x->coord[i].name, new_pointer->data[j].name, 16);					// copy name
			sysmem_copyptr(&x->coord[i].x, &new_pointer->data[j].x,  sizeof(double) * 6);		// copy all coordinates
			j++;
		}
	}
}

//___________________________________________________________________________________________________________________________

// set interpolation time / interpolation mode / time interval

void monitor_interpol_time(t_monitor *x, short n)
{
	x->interpol_time = n;
}

void monitor_interpol_mode(t_monitor *x, short n)
{
	x->interpol_mode = n;
}

void monitor_interval(t_monitor *x, short n)
{
	x->time_interval = (n > 1 ? n : 1);
}

void monitor_set_interpol(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	snapshot *pointer;
	char	 name[8];
	
	switch(av[0].a_type)
	{
		case A_LONG:
			sprintf(name, "%ld", av[0].a_w.w_long);
			pointer = get_snapshot_by_index(x->first_snapshot, name);
			break;
		case A_SYM:
			pointer = get_snapshot_by_index(x->first_snapshot, av[0].a_w.w_sym->s_name);
			break;
		default: return;
	}
			
	if(! pointer)
	{
		error("%s: snapshot '%s' doesn't exist", __EXTERNAL_NAME__, av[0].a_w.w_sym->s_name);
		return;
	}
	
	pointer->time = (ac > 1 && av[1].a_type == A_LONG ? av[1].a_w.w_long : -1);
	pointer->mode = (ac > 2 && av[2].a_type == A_LONG ? av[2].a_w.w_long : -1);
}

//___________________________________________________________________________________________________________________________

// retrieve snapshots

void monitor_int(t_monitor *x, long n)
{
	char name[8];
	snapshot *pointer;
	
	sprintf(name, "%ld", n);
	
	// find snapshot
	pointer = get_snapshot_by_index(x->first_snapshot, name);
	if(pointer)
		monitor_retrieve(x, pointer, x->interpol_time, x->interpol_mode);
}

void monitor_anything(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{	
	short time, mode;
	snapshot *pointer;
		
	// find snapshot
	pointer = get_snapshot_by_index(x->first_snapshot, s->s_name);
	if(pointer)
	{
		time = (ac > 0 && av[0].a_type == A_LONG ?
			av[0].a_w.w_long : (pointer->time == -1 ? x->interpol_time : pointer->time));
		mode = (ac > 1 && av[1].a_type == A_LONG ?
			av[1].a_w.w_long : (pointer->mode == -1 ? x->interpol_mode : pointer->mode));
		monitor_retrieve(x, pointer, time, mode);
	}
}

void monitor_list(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short time, mode;
	char name[8];
	snapshot *pointer;
	
	if(av[0].a_type != A_LONG) return;
	
	sprintf(name, "%ld", av[0].a_w.w_long);
	
	// find snapshot
	pointer = get_snapshot_by_index(x->first_snapshot, name);
	if(pointer)
	{
		time = (av[1].a_type == A_LONG ?
			av[1].a_w.w_long : (pointer->time == -1 ? x->interpol_time : pointer->time));
		mode = (ac > 2 && av[2].a_type == A_LONG ?
			av[2].a_w.w_long : (pointer->mode == -1 ? x->interpol_mode : pointer->mode));
		monitor_retrieve(x, pointer, time, mode);
	}
}

// retrieve snapshots and do interpolation, if necessary

void monitor_retrieve(t_monitor *x, snapshot *pointer, short time, short mode)
{
	short i, j;
	short num_of_points, number;
	
	x->actual_interp_mode = mode;
	
	num_of_points = pointer->num_of_points;
	
	if (time < x->time_interval)
	// no interpolation...
	{
		clock_unset(x->clock); // stop any running interpolation

		for(j=0;j<num_of_points;j++)
		{
			number = pointer->data[j].number;
			strcpy(x->coord[number - 1].name, pointer->data[j].name);							// copy name
			sysmem_copyptr(&pointer->data[j].x, &x->coord[number - 1].x,  sizeof(double) * 6);	// copy aed coordinates
	
			x->coord[number - 1].status = 1;
		
			monitor_output(x,number - 1);
		}

		for(i=0;i<MAXPOINTS;i++)
		{
			// delete points that are not present in target snapshot
			if(x->coord[i].status == 1)
			{
				x->coord[i].status = 0;
			
				for(j=0;j<num_of_points;j++)		
					if(pointer->data[j].number == i + 1) x->coord[i].status = 1;				

				if (x->coord[i].status == 0) monitor_output(x,i);
			}
		}
	}
	else
	// interpolation
	{
		x->remaining_time = time;
		x->target_snapshot = pointer;

		monitor_interpol(x);
	}

	qelem_set(x->m_qelem);
}

void monitor_interpol(t_monitor *x)
{
	short i;
	float distance[3];	
	short number;
	float term = (float)x->time_interval / x->remaining_time;
	
	term = (term > 1 ? 1 : term);
		
	if(x->actual_interp_mode == 0)
	// linear interpolation
	{
		for(i=0;i<x->target_snapshot->num_of_points;i++)
		{
			number = x->target_snapshot->data[i].number;
			if(x->coord[number-1].status)
			{
				// calculate distance between actual value and target value
				distance[0] = x->target_snapshot->data[i].x - x->coord[number-1].x;		
				distance[1] = x->target_snapshot->data[i].y - x->coord[number-1].y;		
				distance[2] = x->target_snapshot->data[i].z - x->coord[number-1].z;
	
				if(distance[0] != 0.0 || distance[1] != 0.0 || distance[2] != 0.0) // only if distance != 0...
				{
					x->coord[number-1].x = x->coord[number-1].x + distance[0] * term;		
					x->coord[number-1].y = x->coord[number-1].y + distance[1] * term;		
					x->coord[number-1].z = x->coord[number-1].z + distance[2] * term;		
	
					monitor_cartopol(&x->coord[number - 1]);
					monitor_output(x, number - 1);
				}
			}
		}
	}
	else								
	// polar interpolation
	{
		for(i=0;i<x->target_snapshot->num_of_points;i++)
		{
			number = x->target_snapshot->data[i].number;
			if(x->coord[number-1].status)
			{
				// calculate distance between actual value and target value
				distance[0] =  x->target_snapshot->data[i].a - x->coord[number-1].a;		
				distance[1] =  x->target_snapshot->data[i].e - x->coord[number-1].e;		
				distance[2] =  x->target_snapshot->data[i].d - x->coord[number-1].d;
			
				// find shortest distance
				distance[0] = (distance[0] >  180 ? distance[0] - 360 : distance[0]);
				distance[0] = (distance[0] < -180 ? distance[0] + 360 : distance[0]);
				
				if(distance[0] != 0.0 || distance[1] != 0.0 || distance[2] != 0.0) // only if distance != 0...
				{
					x->coord[number-1].a = x->coord[number-1].a + distance[0] * term;
					x->coord[number-1].e = x->coord[number-1].e + distance[1] * term;		
					x->coord[number-1].d = x->coord[number-1].d + distance[2] * term;		
	
					monitor_poltocar(&x->coord[number - 1]);
					monitor_output(x, number - 1);
				}
			}
		}
	}
	
	x->remaining_time = x->remaining_time - x->time_interval;
	qelem_set(x->m_qelem);
	
	if(x->remaining_time > 0)
		clock_delay(x->clock, x->time_interval);
	else
		monitor_retrieve(x, x->target_snapshot, 0, 0);
}

void monitor_xfade(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short	i,j;
	char 	name[3];
	float 	distance[3];	
	short 	number, mode;
	float 	term;

	snapshot *pointer1, *pointer2;

		switch(av[0].a_type)
		{
			case(A_LONG):
					sprintf(name, "%ld", av[0].a_w.w_long);
					pointer1 = get_snapshot_by_index(x->first_snapshot, name);
					break;
			case(A_SYM):
					pointer1 = get_snapshot_by_index(x->first_snapshot, av[0].a_w.w_sym->s_name);
					break;
			default: return;
		}
		if(!pointer1) return;

		switch(av[1].a_type)
		{
			case(A_LONG):
					sprintf(name, "%ld", av[1].a_w.w_long);
					pointer2 = get_snapshot_by_index(x->first_snapshot, name);
					break;
			case(A_SYM):
					pointer2 = get_snapshot_by_index(x->first_snapshot, av[1].a_w.w_sym->s_name);
					break;
			default: return;
		}
		if(!pointer2) return;
	
		switch(av[2].a_type)
		{
			case(A_LONG):
				term = CLIP(av[2].a_w.w_long, 0, 1); break;
			case(A_FLOAT):
				term = CLIP(av[2].a_w.w_float, 0, 1); break;
			default:
				term = 0;
		}
		
		switch(av[3].a_type)
		{
			case(A_LONG):
				mode = CLIP(av[3].a_w.w_long, 0, 1); break;	
			default:
				mode = x->interpol_mode;
		}
	
	if(term == 0)
	{
		monitor_retrieve(x, pointer1, 0, 0);
		return;
	}			
	if(term == 1)
	{
		monitor_retrieve(x, pointer2, 0, 0);
		return;
	}				
	
	if(mode == 0)
	// cartesian interpolation
	{
		for(i=0;i<pointer1->num_of_points;i++)
		{
			number = pointer1->data[i].number;
			
			j = 0;
			do
			{
				if(number == pointer2->data[j].number)
				{
					// calculate distance between actual value and target value
					distance[0] = pointer2->data[j].x - pointer1->data[i].x;		
					distance[1] = pointer2->data[j].y - pointer1->data[i].y;		
					distance[2] = pointer2->data[j].z - pointer1->data[i].z;		
	
					x->coord[number-1].x = pointer1->data[i].x + distance[0] * term;		
					x->coord[number-1].y = pointer1->data[i].y + distance[1] * term;		
					x->coord[number-1].z = pointer1->data[i].z + distance[2] * term;		

					strcpy(x->coord[number - 1].name, pointer1->data[i].name);
					x->coord[number-1].status = 1;
	
					monitor_cartopol(&x->coord[number - 1]);
					monitor_output(x, number - 1);
				}
			} while(number != pointer2->data[j].number && j++ < pointer2->num_of_points);

		}
	}
	else								
	// polar interpolation
	{
		for(i=0;i<pointer1->num_of_points;i++)
		{
			number = pointer1->data[i].number;

			j = 0;
			do
			{
				if(number == pointer2->data[j].number)
				{
					// calculate distance between actual value and target value
					distance[0] = pointer2->data[j].a - pointer1->data[i].a;		
					distance[1] = pointer2->data[j].e - pointer1->data[i].e;		
					distance[2] = pointer2->data[j].d - pointer1->data[i].d;
			
					// find shortest distance
					distance[0] = (distance[0] >  180 ? distance[0] - 360 : distance[0]);
					distance[0] = (distance[0] < -180 ? distance[0] + 360 : distance[0]);

					x->coord[number-1].a = pointer1->data[i].a + distance[0] * term;		
					x->coord[number-1].e = pointer1->data[i].e + distance[1] * term;		
					x->coord[number-1].d = pointer1->data[i].d + distance[2] * term;
					
					strcpy(x->coord[number - 1].name, pointer1->data[i].name);
					x->coord[number-1].status = 1;	
	
					monitor_poltocar(&x->coord[number - 1]);
					monitor_output(x, number - 1);
				}
			} while(number != pointer2->data[j].number && ++j < pointer2->num_of_points);
		}
	}

	qelem_set(x->m_qelem);
}

//___________________________________________________________________________________________________________________________

// remove snapshots

void monitor_remove(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	snapshot *pointer;
	char	  name[3];
		
	switch (av[0].a_type)
	{
		case A_LONG:
			sprintf(name, "%ld", av[0].a_w.w_long);
			pointer = get_snapshot_by_index(x->first_snapshot, name); break;
		case A_SYM:
			pointer = get_snapshot_by_index(x->first_snapshot, av[0].a_w.w_sym->s_name); break;
		default: return;
	}
	monitor_snapshot_remove(x, pointer);
}

void monitor_snapshot_remove(t_monitor *x, snapshot *pointer)
{
	if (pointer->prev)
		pointer->prev->next = pointer->next;
	if (pointer->next)
		pointer->next->prev = pointer->prev;
	if (x->first_snapshot == pointer)
		x->first_snapshot = pointer->next;
	if (x->last_snapshot == pointer)
		x->last_snapshot = pointer->prev;
		
	// free allocated memory			
	sysmem_freeptr(pointer);
}

void monitor_remove_all(t_monitor *x)
{
	snapshot *pointer = x->first_snapshot, *next_pointer;
	
	while(pointer)
	{	
		next_pointer = pointer->next;
		// free allocated memory
		sysmem_freeptr(pointer);
		
		pointer = next_pointer;
	}
	
	x->first_snapshot = x->last_snapshot = 0;
}


//___________________________________________________________________________________________________________________________

// find snapshots

void *get_snapshot_by_index(snapshot *pointer, char *index)
{
	while(pointer)
	{
		if(! strcmp(pointer->index, index)) return(pointer);
		pointer = pointer->next;
	}
	return(0);
}

// link in

void monitor_snapshot_link(t_monitor *x, snapshot *pointer)
{
	if(! x->first_snapshot)
		x->first_snapshot = pointer;
	if(x->last_snapshot)
		x->last_snapshot->next = pointer;
	
	pointer->prev = x->last_snapshot;
	pointer->next = 0;

	x->last_snapshot = pointer;
}

//___________________________________________________________________________________________________________________________
//___________________________________________________________________________________________________________________________


// write all snapshots to a XML formatted file

void monitor_write(t_monitor *x, t_symbol *s)
{
	defer_low(x,(method)monitor_dowrite, s, 0, 0L);
}

void monitor_dowrite(t_monitor *x, t_symbol *s, short argc, t_atom *argv)
{
	t_filehandle file;
	char filename[64] = "snapshots.xml";
	short path;
	
	if (!s->s_name[0])
	{
		if (saveas_dialog(filename, &path, 0L))
			return;
	}
			
	else
	{
		strcpy(filename, s->s_name); 
		path = path_getdefault();
	} 

	if (path_createsysfile(filename, path, 'TEXT', &file))
	{
		error("%s: couldn't write snapshots to file \"%s\"", __EXTERNAL_NAME__, filename);
		return;
	}
		
	write_to_file(file, x->first_snapshot);
	
	sysfile_close(file);
}

void write_to_file(t_filehandle file, snapshot *pointer)
{
	short i, err;
	long file_pos;
	long count;
	char c[128];
	
	sprintf(c, "<?xml version=\"1.0\" standalone=\"yes\" encoding=\"UTF-8\"?>\r\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
	
	sprintf(c, "<ambiscore version=\"1.0\">\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);

// coordinate system definition
	sprintf(c, "\t<xyz-def handedness=\"right\" x-axis=\"right\" />\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
	
	while (pointer)
	{				
		// write to file
				
		sprintf(c, "\t<snapshot index = \"%s\">\r", pointer->index);
		count = strlen(c);
		err = sysfile_write(file, &count, c);
		
		if(pointer->time != -1)
		{
			sprintf(c, "\t\t<interpolation_time>%ld</interpolation_time>\r", pointer->time);
			count = strlen(c);
			err = sysfile_write(file, &count, c);
		}

		if(pointer->mode != -1)
		{
			sprintf(c, "\t\t<interpolation_mode>%ld</interpolation_mode>\r", pointer->mode);
			count = strlen(c);
			err = sysfile_write(file, &count, c);
		}
				
		for(i=0;i<pointer->num_of_points;i++)
		{		
			sprintf(c, "\t\t<point>\r\t\t\t<number>%ld</number>\r", pointer->data[i].number);
			count = strlen(c);
			err = sysfile_write(file, &count, c);
			
						
			if(string_to_number(pointer->data[i].name) != pointer->data[i].number)
			{
				sprintf(c, "\t\t\t<name>%s</name>\r", pointer->data[i].name);
				count = strlen(c);
				err = sysfile_write(file, &count, c);
			}
			
			sprintf(c, "\t\t\t<xyz>%f %f %f</xyz>\r\t\t</point>\r",
					pointer->data[i].x, pointer->data[i].y, pointer->data[i].z);
			count = strlen(c);
			err = sysfile_write(file, &count, c);
		}

		sprintf(c, "\t</snapshot>\r");
		count = strlen(c);
		err = sysfile_write(file, &count, c);
		
		pointer = pointer->next;
	}

	sprintf(c, "</ambiscore>");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
			
	sysfile_getpos(file, &file_pos);
	sysfile_seteof(file, file_pos);
}

//___________________________________________________________________________________________________________________________

// read snapshots from a XML formatted file

void monitor_read(t_monitor *x, t_symbol *s)
{
	defer_low(x,(method)monitor_doread, s, 0, 0L);
}

void monitor_doread(t_monitor *x, t_symbol *s, short argc, t_atom *argv)
{
	t_filehandle file = 0;
	char filename[64];
	short path;
	long outtype;
	
	if (!s->s_name[0])
		{if (open_dialog(filename, &path, &outtype, 0L, 0)) return;}
		
	else
	{
		strcpy(filename, s->s_name);
		if (locatefile_extended(filename, &path, &outtype, 0L, 0))
		{
			error("%s: can't find file \"%s\"", __EXTERNAL_NAME__, filename);
			return;
		}
	}

	if (path_opensysfile(filename, path, &file, READ_PERM))
	{
		error("%s: can't open file \"%s\"", __EXTERNAL_NAME__, filename);
		return;
	}

	read_from_file(x, file, filename);
	
	sysfile_close(file);
	
	qelem_set(x->m_qelem);	
}

void read_from_file(t_monitor *x, t_filehandle file, char *filename)
{
	short err=0;
	char tag[64], rem[128];

	do{	err = get_tag(file, tag, rem);
		
		if(	tag[0] != '?' &&
			tag[0] != '!' &&
			strcmp(tag, "ambiscore"))
			{
				error("%s: \"%s\" is no readable ambiscore file", __EXTERNAL_NAME__, filename);
				return;
			}
			
		else if(!strcmp(tag, "ambiscore"))
		{
			monitor_remove_all(x);
			err = read_ambiscore(x,file);
		}			
	} while(!err);
}

// parse data

short read_ambiscore(t_monitor *x, t_filehandle file)
{
	short err=0;
	char tag[64], rem[128];
	
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "snapshot"))
			err = read_snapshot(x,file, rem);
		
	} while(!err);
	
	return(err);
}

short read_snapshot(t_monitor *x, t_filehandle file, char* attr_val)
{
	short err=0;
	char attr[64], val[64], tag[64], rem[64], index[64], data[64];
	short size;
	short time, mode;
	short i, j, num_of_points = 0;
	snapshot *pointer;
	ambi coord[MAXPOINTS];
	
	// initialise coords
	for(i=0;i<MAXPOINTS;i++)
		coord[i].status = 0;
	time = mode = -1;
	
	// get index	
	get_attr_value_pair(attr_val, attr, val, attr_val);
	
	if(!strcmp(attr, "index"))
		strcpy(index, val);
	else
		strcpy(index, "1"); 	// default index

	// iterate though entries
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "point"))
		{
			err = read_point(file, coord);
			num_of_points++;
		}
		
		if(!strcmp(tag, "interpolation_time"))
		{
			err = get_data(file, data);
			remove_space_from_string(data);
			time = string_to_number(data);
		}
		
		if(!strcmp(tag, "interpolation_mode"))
		{
			err = get_data(file, data);
			remove_space_from_string(data);
			mode = string_to_number(data);
		}

		if(!strcmp(tag, "/snapshot"))
		{
		// create new snapshot...	

			pointer = get_snapshot_by_index(x->first_snapshot, index);			
			// ...but only, if no snapshot with this index already exists			
			if(pointer) return(0);
			
			// allocate memory
			size = sizeof(snapshot) + (num_of_points - 1) * sizeof(coords);
			pointer = (snapshot *)sysmem_newptr(size);
			
			// build linked list
			monitor_snapshot_link(x, pointer);
			
			// write index
			pointer->index = sysmem_newptr(sizeof(index));
			strcpy(pointer->index, index);
			
			// write header
			pointer->num_of_points = num_of_points;
			pointer->time = time;		
			pointer->mode = mode;		
		
			// write data
			for(i=0,j=0;i<MAXPOINTS && j<num_of_points;i++)
			{
				if(coord[i].status)
				{
					strcpy(pointer->data[j].name, coord[i].name);
					sysmem_copyptr(&coord[i].x, &pointer->data[j].x, sizeof(double) * 6);
					pointer->data[j].number = i+1;
					j++;
				}
			}
			return(0);			
		}
		
	} while(!err);
	
	return(err);
}

short read_point(t_filehandle file, ambi *coord)
{
	short	err=0;
	short	number;
	short	format=0; // 0=aed  1=xyz
	char	name[16];
	ambi	temp;
	char	data[64], tag[64], rem[64];
	
	
	number = 1;								// default number
	string_to_triplet("0 0 1", &temp.a);	// default coordinates
	name[0] = '\0';
	
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "number"))
		{	err = get_data(file, data);
			remove_space_from_string(data);
			number = string_to_number(data);
		}
		
		if(!strcmp(tag, "name"))
		{	err = get_data(file, data);
			data[15] = '\0';
			remove_space_from_string(data);
			strcpy(name, data);		
		}
			
		if(!strcmp(tag, "xyz"))
		{	err = get_data(file, data);
			string_to_triplet(data, &temp.x);
			format = 1;
		}		

		if(!strcmp(tag, "aed"))
		{	err = get_data(file, data);
			string_to_triplet(data, &temp.a);
			format = 0;
		}		
		
		if(!strcmp(tag, "coord"))
		{	err = get_data(file, data);
			string_to_triplet(data, &temp.a);
			format = 0;
		}
		
		if(!strcmp(tag, "/point") && coord[number-1].status == 0)
		{
			if(format == 0)
				monitor_poltocar(&temp);
			if(format == 1)
				monitor_cartopol(&temp);
				
			sysmem_copyptr(&temp, &coord[number-1], sizeof(double) * 6);
			
			coord[number-1].status = 1;
			
			if(name[0] != '\0')
				strcpy(coord[number-1].name, name);
			else
				sprintf(coord[number-1].name, "%ld", number);
			return(0);
		}
		
	} while(!err);
	
	return(err);
}

//___________________________________________________________________________________________________________________________

// getting tags, attributes and data from XML file

short get_tag(t_filehandle file, char *tag, char *rem)
{
	char buf;
	short err, i=0;
	
	do
	{if(file_getchar(file, &buf)) return(1);
	} while(buf != '<');
	
	if(file_getchar(file, &buf)) return(1);
	if(buf == '?')
	{
		tag[i++] = buf;
		do
		{if(file_getchar(file, &tag[i++])) return(1);
		} while (tag[i-1] != '>');
		
		tag[i-1] = '\0';
		rem[0] = '\0';
		return(0);
	}
	
	if(buf == '!')
	{
		tag[i++] = buf;
		do
		{if(file_getchar(file, &tag[i++])) return(1);
		} while (tag[i-1] != '>');
		
		tag[i-1] = '\0';
		rem[0] = '\0';
		return(0);
	}
	
	if(white_space(buf))
	{
		do
		{if(file_getchar(file, &buf)) return(1);
		} while(white_space(buf));
	}

	tag[i++] = buf;
	
	do
	{if(file_getchar(file, &tag[i++])) return(1);
	} while (! white_space(tag[i-1]) && tag[i-1] != '>');
	
	if(tag[i-1] == '>') {tag[i-1] = '\0'; rem[0] = '\0'; return(0);}
	tag[i-1] = '\0';
	
	do
	{if(file_getchar(file, &buf)) return(1);
	} while(white_space(buf));
	
	i=0;
	rem[i++] = buf;
	
	do
	{if(file_getchar(file, &rem[i++])) return(1);
	} while (rem[i-1] != '>');
	
	rem[i-1] = '\0';
	return(0);
}

short get_attr_value_pair(char *buf, char *attr, char *value, char *rem)
{
	short i=0, j=0;
	
	while(white_space(buf[i])) i++;
	
	if(buf[i] == '\0')
	{
		attr[0] = '\0';
		value[0] = '\0';
		rem[0] = '\0';
		return(0);
	}
						
	while(! white_space(buf[i]) && buf[i] != '=' && buf[i] != '\0')
		attr[j++] = buf[i++];
	
	attr[j] = '\0';

	if(buf[i] == '\0') return(1);
							
	while(white_space(buf[i])) i++;
		
	if(buf[i] == '\0') return(1);
	if(buf[i++] != '=') return(1);
					
	while(white_space(buf[i])) i++;
		
	if(buf[i] == '\0') return(1);
	if(buf[i++] != '\"') return(1);
												
	while(white_space(buf[i])) i++;
		
	if(buf[i] == '\0') return(1);

	j=0;
	while(! white_space(buf[i]) &&buf[i] != '\"' && buf[i] != '\0')
		value[j++] = buf[i++];
		
	value[j] = '\0';

	while(white_space(buf[i]) || buf[i] == '\"') i++;
	
	if(buf[i] == '\0') {rem[0] = '\0'; return(0);}
	
	j=0;
	while(buf[i] != '\0')
		rem[j++] = buf[i++];
		rem[j] = '\0';
	return(0);
}

short get_data(t_filehandle file, char* data)
{
	short err=0, i=0;
	
	do
	{if(file_getchar(file, &data[i++])) return(1);
	} while(data[i-1] != '<');
	
	data[i-1] = '\0';
	
	return(err);
}

//___________________________________________________________________________________________________________________________

// utility functions

short file_getchar(t_filehandle file, char *c)
{
	long count = 1;
	short err;
#ifdef WIN_VERSION
	long pos, eof;
#endif
	
	err = sysfile_read(file, &count, c);
	
#ifdef WIN_VERSION
	sysfile_getpos(file, &pos);
	sysfile_geteof(file, &eof);
	if(pos == eof) err = 1;
#endif

	return err;
}

short white_space(char c)
{
	if(	c == 0x20 ||	// space
	 	c == 0x9  ||	// TAB
	 	c == 0xA  ||	// line feed
	 	c == 0xB  ||	// vertical tab
	 	c == 0xC  ||	// form feed
	 	c == 0xD )		// carriage return
		return(1);
	else return(0);
}

void remove_space_from_string(char *str)
{
	short i=0, j=0;
	
	do{	str[j] = str[i];
		if(! white_space(str[i])) j++;
		} while(str[i++] != '\0');
}	

short string_to_number(char *name)
{
	short i, j, x = 0;
	
	for(i=strlen(name), j=1;i>0;i--, j=j*10)
	{	x = x + (name[i-1] - 48) * j;
	}
	
	return(x);	
}

void string_to_triplet(char *string, double *coord_triplet)
// used for reading coordinate data triplets
{
	short i=0, j;
	float k;
	short sign;
	float value;

	for(j=0;j<3;j++)
	{
		value = 0; sign = 1; k = 0.1;
		while(white_space(string[i])) i++;
		
		if(string[i] == '-') {sign = -1;i++;}
	
		// string to float
		while(string[i] > 47 && string[i] < 58)
		{value = value * 10 + string[i++] - 48;
		}
	
		if(string[i] == '.')
		{
			i++;
			while(string[i] > 47 && string[i] < 58)
			{value = value + (string[i++] - 48) * k;
			k = k * 0.1;
			}
		}
		coord_triplet[j] = value * sign;
	}
}

//___________________________________________________________________________________________________________________________
