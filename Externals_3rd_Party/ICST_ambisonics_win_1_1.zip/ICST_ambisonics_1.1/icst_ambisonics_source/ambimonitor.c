/* 

	ambimonitor.c	GUI object for ambisonic sound spatialisation
					part of the ICST Ambisonics Tools

	Copyright (C) 2005 - 2006 ICST Zurich / Philippe Kocher
	
	http://www.icst.net
	

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
	
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
	
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	
	
	2006/06/18 Version 1.1	minor bugfixes, ported to PC, font and zoom added
	2006/03/27 Version 1.0	initial release

*/

#define __VERSION__ "1.1"
#define __EXTERNAL_NAME__ "ambimonitor"

#include "ambimonitor.h"
#include "snapshots.c"


void *monitor_class;

//___________________________________________________________________________________________________________________________

// main function

void main(void)
{	
	setup((t_messlist **)&monitor_class, (method)monitor_new, (method)monitor_free,
			(short)sizeof(t_monitor), (method)monitor_menu, A_GIMME, 0);
				
	// points
	addmess((method)monitor_xyz_input,  	"xyz",			A_GIMME, 0);
	addmess((method)monitor_aed_input,  	"aed",			A_GIMME, 0);
	addmess((method)monitor_set_input,  	"set",			A_GIMME, 0);
	addmess((method)monitor_clear,	    	"clear",		0);
	addmess((method)monitor_delete,	    	"delete",		A_GIMME, 0);
	addmess((method)monitor_rename,			"rename",		A_GIMME, 0);
	addmess((method)monitor_dump,	    	"dump",			0);

	// options
	addmess((method)monitor_mode,			"mode",			A_LONG, 0);
	addmess((method)monitor_size,		 	"size",			A_LONG,	0);
	addmess((method)monitor_numbers,    	"numbers", 		A_LONG,	0);
	addmess((method)monitor_coordinates,	"coordinates",	A_LONG,	0);
	addmess((method)monitor_lines,			"lines",		A_LONG,	0);
	addmess((method)monitor_grid,			"grid",			A_LONG,	0);
	addmess((method)monitor_offset,			"offset",		A_LONG,	0);

	// zoom
	addmess((method)monitor_zoom,			"zoom",			A_GIMME, 0);

	// enable / disable keyboard and mouse
	addmess((method)monitor_local,			"local",		A_LONG, 0);
	addmess((method)monitor_enablekeys,		"enablekeys",	A_LONG, 0);

	// snapshots	
	addint((method)monitor_int);
	addmess((method)monitor_anything,		"anything",		A_GIMME, 0),
	addmess((method)monitor_list,	    	"list",			A_GIMME, 0);
	addmess((method)monitor_store,			"store",		A_GIMME, 0);
	addmess((method)monitor_remove,			"remove",		A_GIMME, 0);
	addmess((method)monitor_remove_all,		"remove_all",	0);
	addmess((method)monitor_interpol_time,	"interpolation_time",	A_LONG,	0);
	addmess((method)monitor_interpol_mode,	"interpolation_mode",	A_LONG,	0);
	addmess((method)monitor_set_interpol,	"set_interpolation",	A_GIMME, 0);
	addmess((method)monitor_xfade,			"xfade",		A_GIMME, 0);
	addmess((method)monitor_interval,		"interval",		A_LONG,	0);
	addmess((method)monitor_write,			"write",		A_DEFSYM, 0);
	addmess((method)monitor_read,			"read",			A_DEFSYM, 0);

	// grid units
	addmess((method)monitor_gridunit_xyz,	"gridunit_xyz",	A_FLOAT,0);
	addmess((method)monitor_gridunit_ae,	"gridunit_ae",	A_LONG, 0);
	addmess((method)monitor_gridunit_d,		"gridunit_d",	A_FLOAT,0);

	// keyboard commands
	addmess((method)monitor_nudgeunit_xyz,	"nudgeunit_xyz",A_FLOAT,0);
	addmess((method)monitor_nudgeunit_a,	"nudgeunit_a",	A_FLOAT,0);
	addmess((method)monitor_nudgeunit_d,	"nudgeunit_d",	A_FLOAT,0);

	// display colors
	addmess((method)monitor_set_point_color,	"rgb1", 	A_GIMME, 0);
	addmess((method)monitor_set_name_color,		"rgb2", 	A_GIMME, 0);
	addmess((method)monitor_set_coord_color,	"rgb3", 	A_GIMME, 0);
	addmess((method)monitor_set_line_color,		"rgb4", 	A_GIMME, 0);
	addmess((method)monitor_set_circle_color,	"rgb5", 	A_GIMME, 0);
	addmess((method)monitor_set_background_color,"rgb6", 	A_GIMME, 0);
	addmess((method)monitor_set_grid_color,		"rgb7",		A_GIMME, 0);
	addmess((method)monitor_set_hi_grid_color,	"rgb8",		A_GIMME, 0);

	// report internal status
	addmess((method)monitor_version,		"version",		0);
	addmess((method)monitor_report,			"report",		0);
		
	// methods for messages sent by ambicontrol
	addmess((method)monitor_output_coord,	"output_coord",	A_CANT, 0);
	addmess((method)monitor_add_graph_new,	"add_graph_new",A_CANT, 0);
	addmess((method)monitor_add_graph_remove,"add_graph_remove",A_CANT, 0);
	addmess((method)monitor_update_graphics,"update_graphics", A_CANT, 0);
	
	// methods for messages sent by Max
	addmess((method)monitor_key,			"key",			A_CANT, 0);
	addmess((method)monitor_update,			"update",   	A_CANT, 0);
	addmess((method)monitor_click,			"click",		A_CANT, 0);
	addmess((method)monitor_bfont,			"bfont",		A_CANT, 0);
	addmess((method)monitor_assist,			"assist",		A_CANT, 0);
	addmess((method)inspector_open,			"info",			A_CANT, 0);
	addmess((method)monitor_psave,			"psave",		A_CANT, 0);
	addmess((method)monitor_enter,			"enter",		A_CANT, 0);
	
	post("ambimonitor    -    Philippe Kocher/ICST Zurich    -    � 2006");
}

//___________________________________________________________________________________________________________________________

// object creation function

// the user selects the object from the menu or toobar 
//		we need to supply the _new method with default values

void *monitor_menu(t_patcher *p, long x, long y, long font)
{
	t_atom av[11];

	SETOBJ(av,(t_object *)p);
	SETLONG(av+1, x);
	SETLONG(av+2, y);
							// set default values...
	SETLONG(av+3, 200);		// width
	SETLONG(av+4, 200);		// height
	SETLONG(av+5, 0);		// mode
	SETLONG(av+6, 0);		// grid
	SETLONG(av+7, 0);		// numbers
	SETLONG(av+8, 0);		// coordinates
	SETLONG(av+9, 0);		// lines
	SETLONG(av+10,0);		// offset
		
	return monitor_new(gensym("ambimonitor"),11,av);
}

void *monitor_new(t_symbol *s, short ac, t_atom *av)
{
	short i;	
	t_monitor *x;
	short left, top, hsize, vsize, flags;
	
	x = (t_monitor *)newobject(monitor_class);
	
 	x->patcher = (t_patcher *)av->a_w.w_obj; // get patcher from av
	gensym("#X")->s_thing = (t_object *)x;
		
	// box coordinates
 	left	= av[1].a_w.w_long; 
	top		= av[2].a_w.w_long;
	hsize	= av[3].a_w.w_long;
	vsize	= av[4].a_w.w_long;
		
	// create box
	flags = F_DRAWFIRSTIN | F_DRAWINLAST| F_HILITE;
	box_new((t_box *)x, x->patcher, flags, left, top, left+hsize, top+vsize);

#ifdef WIN_VERSION  // offscreen drawing not necessary for OSX
	monitor_alloc_offscreen(x);
#endif
	
	// create outlets
	x->m_outlet2 = outlet_new(x, 0L);
	x->m_outlet1 = outlet_new(x, 0L);

	// create inlet	
	x->m_box.b_firstin = (void *)x;
	
	// monitor_update is used as queue function
	x->m_qelem = qelem_new(x, (method)monitor_redraw);
		
	// initialise variables
	x->mode = av[5].a_w.w_long;
	x->grid = av[6].a_w.w_long;
	x->numbers = av[7].a_w.w_long;
	x->coordinates = av[8].a_w.w_long;
	x->lines = av[9].a_w.w_long;
	x->offset = av[10].a_w.w_long;
	
	x->zoom_factor = 1;
	x->zoom_focal_point_x = 0;
	x->zoom_focal_point_y = 0;
	
	x->local = 1;
	x->enablekeys = 1;

	x->nudgeunit_xyz = 0.01;
	x->nudgeunit_a = 1.0;
	x->nudgeunit_d = 0.1;
	
	x->gridunit_xyz = 0.1;
	x->gridunit_ae = 6;
	x->gridunit_d = 0.1;
	
	x->time_interval = 20;
	
	x->additional_graphics = 0;
		
	// initialise coordinates
	for(i=0;i<MAXPOINTS;i++)
	{
		x->coord[i].status = 0;
		x->coord[i].active = 0;
		x->coord[i].sel = 0;
	}
	
	// initialise clock
	x->clock = clock_new(x,(method)monitor_interpol);
	
	// initialise colors
	x->point_color	= POINTColor;
	x->name_color	= NAMEColor;
	x->coord_color	= COORDColor;
	x->line_color	= LINEColor;			// lines
	
	x->circle_color	= CIRCLEColor;			// radar
	x->background_color = BACKGROUNDColor;
	
	x->grid_color	= GRIDColor;			// grid
	x->hi_grid_color= HI_GRIDColor;

	x->rect_color	= RECTColor;			// selection rect

	// get default font number and size from parent patcher
	x->fontnum = x->patcher->p_deffont;
	x->fontsize = x->patcher->p_defsize;
	
	// message string initialisation
	symbol_xyz = gensym("xyz");
	symbol_aed = gensym("aed");
		
	// return the object's pointer
	box_ready((t_box *)x);
	return (x);	
}

//___________________________________________________________________________________________________________________________

void monitor_redraw(t_monitor *x)
{
	GrafPtr gp;

	if (gp = XQT_patcher_setport(x->m_box.b_patcher))  // set grafport to patcher
	{ 
		if (!XQT_box_nodraw((t_box *)x))
		{ 
			monitor_update(x);
			XQT_box_enddraw((t_box *)x); 
		}  
 	XQT_patcher_restoreport(gp); 
	}
} 

void monitor_update_graphics(t_monitor *x)
{
	qelem_set(x->m_qelem);
}



void monitor_update(t_monitor *x)
{
#ifdef WIN_VERSION
	GrafPtr gp = XQT_patcher_setport(x->m_box.b_patcher);
	if(gp)
	{
		if(x->offrect.right != x->m_box.b_rect.right - 1)
			monitor_alloc_offscreen(x);

		monitor_do_update(x);
	}

	XQT_patcher_restoreport(gp);
	
#else	// Macintosh
	monitor_do_update(x);
#endif
}

// windows stuff
// -----------------------------------------------------------------------------------------
#ifdef WIN_VERSION

void monitor_alloc_offscreen(t_monitor *x)
{
	OSErr		err;
	GrafPtr		currPort, offPort;
	GDHandle	currDevice;
	Rect		offrect;

	// dispose existing offscreen
	if(x->offscreen) DisposeGWorld(x->offscreen);

	// define offscreen canvas area
	SetRect(&offrect,	x->m_box.b_rect.left + 1,
						x->m_box.b_rect.top + 1,
						x->m_box.b_rect.right - 1,
						x->m_box.b_rect.bottom - 1);
	x->offrect = offrect;

	// create offscreen canvas
	err = NewGWorld(&x->offscreen, 16, &offrect, NIL, NIL, 0);
	if(err)
		post("error %ld creating offscreen", err);
	else
	{
		GetGWorld((CGrafPtr *)&currPort, &currDevice);
		SetGWorld((CGrafPtr)x->offscreen, NIL);
		EraseRect(&offrect);
		SetGWorld((CGrafPtr)currPort, currDevice);
	}
}

#endif

// monitor update function  (where all the drawing is done)
// -----------------------------------------------------------------------------------------

void monitor_do_update(t_monitor *x)
{
#ifdef WIN_VERSION
	GWorldPtr	offscreen = x->offscreen;
	GrafPtr		currPort, offPort;
	GDHandle	currDevice;
	
	Rect offrect = x->offrect;
#endif

	Rect r;
	char c[30], ok[4] = "ok?";
	short text_width;
	short i;
									// coordinates on the screen
									//  
	short p_x1, p_y1, p_y2;			// point
	short n_x1, n_y1, n_y2;			// number
	short c_x1, c_y1;				// coordinates
	
	double g_x;						// grid

									// additional graphics
	long a_top1, a_top2, a_left, a_bottom1, a_bottom2, a_right;
	long a_x, a_y1, a_y2;
	double *data;
	
	short s_x1, s_y1, s_x2, s_y2;	// selection
	
	add_gr	*pointer;
		
	short left = x->m_box.b_rect.left;
	short top = x->m_box.b_rect.top;
	short right = x->m_box.b_rect.right;
	short bottom = x->m_box.b_rect.bottom;
	
	short size;
		
#ifdef MAC_VERSION	
	RgnHandle old,boxclip;
#endif

	// get current box size
	x->h_size = x->m_box.b_rect.right - x->m_box.b_rect.left;

	// check the object's name
	monitor_name(x);
	
	// check width of box, minimum = 100
	if(x->h_size <= 100)
	{
		x->m_box.b_rect.right = x->m_box.b_rect.left + 100;
		x->h_size = 100;
	}
	
	switch(x->mode)
	{
		case 0:
		x->m_box.b_rect.bottom = x->m_box.b_rect.top + x->h_size; break;
		case 1:
		x->m_box.b_rect.bottom = x->m_box.b_rect.top + x->h_size * 1.5 + 4.5; break;
		case 2:
		x->m_box.b_rect.bottom = x->m_box.b_rect.top + x->h_size * 2; break;	
	}
	bottom = x->m_box.b_rect.bottom;


#ifdef MAC_VERSION
	// clip region
	SetRect(&r, left+1, top+1, right-1, bottom-1);
	GetClip(old = NewRgn());						// get existing clip region 
 	RectRgn(boxclip = NewRgn(), &r);				// box's rect as region 
	SectRgn(old,boxclip,boxclip);					// intersect them 
	SetClip(boxclip);								// make current clip region 
 
#else	// Windows	
	// save the current graphics port and set the drawing to the offscreen
	GetGWorld((CGrafPtr *)&currPort, &currDevice);
	SetGWorld((CGrafPtr)offscreen, NIL);
	offPort = (GrafPtr)offscreen;
#endif

		// draw Background
		SetRect(&r, left+1, top+1, right-1, bottom-1);
		RGBBackColor(&x->background_color);
		EraseRect (&r);
		RGBBackColor(&WHITE);
		
	// calculate zoom view (only if mode == 0)
	size = x->h_size;

	if(x->mode == 0)
	{
		size = size * x->zoom_factor;	
		left = left - x->zoom_focal_point_x * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
		top  = top  + x->zoom_focal_point_y * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
	}
	
	// drawing...
		
		//draw radar

		RGBForeColor(&x->circle_color);
		
		SetRect(&r,	left + 5,
					top  + 5,
					left + size - 5,
					top  + size - 5);
		PaintOval(&r);						// xy-radar
		
		SetRect(&r,	left + 5,
					top  + size + 5,
					left + size - 5,
					top  + size*2 - 5);
		if(x->mode == 1)
			PaintArc(&r, -90, 180);			// yz-radar
		if(x->mode == 2)
			PaintOval(&r);
		
		// draw grid
		switch (x->grid)
		{
			case 1:		// aed grid
				g_x = x->gridunit_d * (size - 10) * 0.5;
				while(g_x <= (size - 10) * 0.5 + 0.5)
				{
					RGBForeColor(&x->grid_color);
					
					SetRect(&r, left + size * 0.5 - g_x,
								top  + size * 0.5 - g_x,
								left + size * 0.5 + g_x + 0.5,
								top  + size * 0.5 + g_x + 0.5);
					FrameOval(&r);
					
					SetRect(&r, left + size * 0.5 - g_x,
								top  + size * 0.5 - g_x + size,
								left + size * 0.5 + g_x + 0.5,
								top  + size * 0.5 + g_x + 0.5 + size);
					if(x->mode == 1)
						FrameArc(&r, -90, 180);
					if(x->mode == 2)
						FrameOval(&r);
						
					g_x += x->gridunit_d * (size - 10) * 0.5;
				}

				if(x->gridunit_ae > 2)
				{
					RGBForeColor(&x->grid_color);

					for(i=1;i<x->gridunit_ae;i++)
					{
						if(i != x->gridunit_ae * 0.5)
						{						
							MoveTo(left + cos((i+x->gridunit_ae) * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5,
								   top  + sin((i+x->gridunit_ae) * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5);
							LineTo(left + cos(i * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5,
								   top  + sin(i * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5);

							MoveTo(left + cos((i+x->gridunit_ae) * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5,
								   top  + sin((i+x->gridunit_ae) * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 1.5);
							if(x->mode == 1)
								LineTo(left + size * 0.5,
									   top  + (size - 10) * 0.5 + 5 + size);
							if(x->mode > 1)
								LineTo(left + cos(i * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 0.5,
									   top  + sin(i * PI / x->gridunit_ae) * (size - 10) * 0.5 + size * 1.5);
						} 
					} 
				}

				// highlighted grid
				RGBForeColor(&x->hi_grid_color);
				
				if(x->gridunit_ae > 0)
				{
					// "horizontal" line through centre (xy radar)
					MoveTo(left + 5, top + (size-10) * 0.5 + 4.5);
					LineTo(left + size - 6, top + (size-10) * 0.5 + 4.5);
				
					// "vertical" line through centre (xy radar)
					if(x->gridunit_ae % 2 == 0)
					{
						MoveTo(left + (size-10) * 0.5 + 4.5, top + 5);
						LineTo(left + (size-10) * 0.5 + 4.5, top + size-6);
					}
				}
				
				if(x->mode > 0 && x->gridunit_ae > 0)
				{
					// "horizontal" line through centre (xz radar)
					MoveTo(left + 5, top + (size-10) * 0.5 + 4.5 + size);
					LineTo(left + size-6, top + (size-10) * 0.5 + 4.5 + size);
				
					// "vertical" line through centre (xz radar)
					if(x->gridunit_ae % 2 == 0)
					{
						MoveTo(left + (size-10) * 0.5 + 5, top + 5 + size);
						if(x->mode == 1)
							LineTo(left + (size-10) * 0.5 + 5, top + (size-10) * 0.5 + 4 + size);	
						if(x->mode == 2)
							LineTo(left + (size-10) * 0.5 + 5, top + size - 6 + size);
					}
				}				
				break;
											
			case 2:		// xyz grid
				g_x = x->gridunit_xyz * (size - 10) * 0.5;
				while(g_x < size * 0.5)
				{					
					RGBForeColor(&x->grid_color);

					MoveTo(left + 5, top + (size - 10) * 0.5 + 5 + g_x);
					LineTo(left + size-5, top + (size - 10) * 0.5 + 5 + g_x);
					MoveTo(left + 5, top + (size - 10) * 0.5 + 5 - g_x);
					LineTo(left + size-5, top + (size - 10) * 0.5 + 5 - g_x);
					
					MoveTo(left + (size - 10) * 0.5 + 5 + g_x, top + 5);
					LineTo(left + (size - 10) * 0.5 + 5 + g_x, top + size - 5);
					MoveTo(left + (size - 10) * 0.5 + 5 - g_x, top + 5);
					LineTo(left + (size - 10) * 0.5 + 5 - g_x, top + size - 5);
					
					if(x->mode >= 1)
					{
						MoveTo(left + 5, top + (size - 10) * 0.5 + 5 - g_x + size);
						LineTo(left + size - 5, top + (size - 10) * 0.5 + 5 - g_x + size);	
					}
					if(x->mode == 2)
					{
						MoveTo(left + 5, top + (size - 10) * 0.5 + 5 + g_x + size);
						LineTo(left + size - 5, top + (size - 10) * 0.5 + 5 + g_x + size);
					}
					
					MoveTo(left + (size - 10) * 0.5 + 5 - g_x, top + 5 + size);
					if(x->mode == 1)
						LineTo(left + (size - 10) * 0.5 + 5 - g_x, top + (size - 10) * 0.5 + 5 + size);	
					if(x->mode == 2)
						LineTo(left + (size - 10) * 0.5 + 5 - g_x, top + size - 5 + size);					

					MoveTo(left + (size - 10) * 0.5 + 5 + g_x, top + 5 + size);
					if(x->mode == 1)
						LineTo(left + (size - 10) * 0.5 + 5 + g_x, top + (size - 10) * 0.5 + 5 + size);	
					if(x->mode == 2)
						LineTo(left + (size - 10) * 0.5 + 5 + g_x, top + size - 5 + size);					

					g_x += x->gridunit_xyz * (size - 10) * 0.5;
					
				}
				RGBForeColor(&x->hi_grid_color);
				
				MoveTo(left + 5, top + (size - 10) * 0.5 + 5);
				LineTo(left + size - 5, top + (size - 10) * 0.5 + 5);
				MoveTo(left + (size - 10) * 0.5 + 5, top + 5);
				LineTo(left + (size - 10) * 0.5 + 5, top + size - 5);
				
				MoveTo(left + 5, top + (size - 10) * 0.5 + 5 + size);
				LineTo(left + size - 5, top + (size - 10) * 0.5 + 5 + size);
				MoveTo(left + (size - 10) * 0.5 + 5, top + 5 + size);
				if(x->mode == 1)
					LineTo(left + (size - 10) * 0.5 + 5, top + (size - 10) * 0.5 + 5 + size);	
				if(x->mode == 2)
					LineTo(left + (size - 10) * 0.5 + 5, top + size - 5 + size);					
				break;
		}
		
		// draw additional graphics (boxes and trajectories), if any
		pointer = x->additional_graphics;
		while(pointer)
		{
			data = *pointer->data;
			switch(pointer->type)
			{
				case 1:	// rectangle
				{
					a_left	= left + (1 + *(data)) * (size - 10) * 0.5 + 5;
					a_top1	= top  + (1 - *(data+4)) * (size - 10) * 0.5 + 5;
					a_top2	= top  + (1 - *(data+5)) * (size - 10) * 0.5 + 5 + size;
					a_right = left + (1 + *(data+3)) * (size - 10) * 0.5 + 5;
					a_bottom1 = top +(1 - *(data+1)) * (size - 10) * 0.5 + 5;
					a_bottom2 = top +(1 - *(data+2)) * (size - 10) * 0.5 + 5 + size;
					// swap y and z max/min!

					RGBForeColor(pointer->color);
					
					SetRect(&r, a_left-1, a_top1-1, a_right+1, a_bottom1+1);
					FrameRect(&r);
					PenMode(blend);
					OpColor(&OPAQUE_BOX);
					PaintRect(&r);
					PenNormal();
					
					if(x->mode > 0)
					{
						SetRect(&r, a_left-1, a_top2-1, a_right+1, a_bottom2+1);
						FrameRect(&r);
						PenMode(blend);
						OpColor(&OPAQUE_BOX);
						PaintRect(&r);
						PenNormal();
					}
					break;
				}
				case 2: // breakpoint graph
				{
					if(!data) break;
					a_x  = left + (1 + *(data))   * (size - 10) * 0.5 + 5;
					a_y1 = top  + (1 - *(data+1)) * (size - 10) * 0.5 + 5;
					
					RGBForeColor(pointer->color);
					
					MoveTo(a_x, a_y1);

					for(i=0;i< *(pointer->number)*3;i+=3)
					{
						a_x  = left + (1 + *(data+i))   * (size - 10) * 0.5 + 5;
						a_y1 = top  + (1 - *(data+i+1)) * (size - 10) * 0.5 + 5;
						
						LineTo(a_x, a_y1);
					}
					
					if(x->mode > 0)
					{
						a_x  = left + (1 + *(data))   * (size - 10) * 0.5 + 5;
						a_y2 = top  + (1 - *(data+2)) * (size - 10) * 0.5 + 5 + size;

						MoveTo(a_x, a_y2);
					
						for(i=0;i< *(pointer->number)*3;i+=3)
						{
							a_x  = left + (1 + *(data+i))   * (size - 10) * 0.5 + 5;
							a_y2 = top  + (1 - *(data+i+2)) * (size - 10) * 0.5 + 5 + size;
						
							LineTo(a_x, a_y2);
						}
					}
				}			
			}
			pointer = pointer->next;
		}
		
		// draw points, numbers/names & coordinates
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].status != 0)
			{
				RGBForeColor(&x->point_color);

				p_x1 = left + (1 + x->coord[i].x) * (size - 10) * 0.5 + 5;
				p_y1 = top  + (1 - x->coord[i].y) * (size - 10) * 0.5 + 5;		
				p_y2 = top  + (1 - x->coord[i].z) * (size - 10) * 0.5 + 5 + size;
					
				SetRect(&r, p_x1-RADIUS, p_y1-RADIUS, p_x1+RADIUS, p_y1+RADIUS);
				if(x->coord[i].active)
					PaintOval(&r);
				else
				{	FrameOval(&r);
					PenMode(blend);
					OpColor(&OPAQUE_POINT);
					PaintOval(&r);
					PenNormal();
				}				
					
				if(x->mode > 0)
				{
					SetRect(&r, p_x1-RADIUS, p_y2-RADIUS, p_x1+RADIUS, p_y2+RADIUS);
					if(x->coord[i].active)
						PaintOval(&r);
					else
					{	FrameOval(&r);
						PenMode(blend);
						OpColor(&OPAQUE_POINT);
						PaintOval(&r);
						PenNormal();					
					}
					
					if(x->lines)
					{
						RGBForeColor(&x->line_color);

						MoveTo(p_x1, p_y1+RADIUS);
						LineTo(p_x1, p_y2-RADIUS);
					}
				}	
				if(x->numbers &&
					p_x1+RADIUS >  x->m_box.b_rect.left && p_x1-RADIUS <  x->m_box.b_rect.right	&&	// only if point is visible (zoom...)
					p_y1+RADIUS >  x->m_box.b_rect.top)

				{
					XQT_TextSize(x->fontsize * 4/3);
					XQT_TextFont(x->fontnum);

					strcpy(c, x->coord[i].name);
					text_width = TextWidth(c, 0, strlen(c)); 

					if(p_x1 < x->m_box.b_rect.right - text_width - 10)
						n_x1 = left + (1 + x->coord[i].x) * (size - 10) * 0.5 + 10;
					else				
						n_x1 = left + (1 + x->coord[i].x) * (size - 10) * 0.5 - text_width;
					
					n_y1 = top + (1 - x->coord[i].y) * (size - 10) * 0.5 + 8;
					n_y2 = top + (1 - x->coord[i].z) * (size - 10) * 0.5 + 8 + size;
			
					RGBForeColor(&x->name_color);		
					
					MoveTo(n_x1, n_y1);
					DrawText(c, 0, strlen(c));
			
					if (x->mode != 0)
					{
						MoveTo(n_x1, n_y2);
						DrawText(c, 0, strlen(c));
					}
				}
	
				if(x->coordinates &&
					p_x1+RADIUS >  x->m_box.b_rect.left && p_x1-RADIUS <  x->m_box.b_rect.right	&&	// only if point is visible (zoom...)
					p_y1+RADIUS >  x->m_box.b_rect.top)
				{	
					RGBForeColor(&x->coord_color);
		
					XQT_TextSize(x->fontsize);
					XQT_TextFont(x->fontnum);
										
					if(x->coordinates == 1)
						sprintf(c, "a: %2.2f  e: %2.2f  d: %2.2f", x->coord[i].a, x->coord[i].e, x->coord[i].d);
					else
						sprintf(c, "x: %2.2f  y: %2.2f  z: %2.2f", x->coord[i].x, x->coord[i].y, x->coord[i].z);

					text_width = TextWidth(c, 0, strlen(c)); 

					c_x1 = left + (1 + x->coord[i].x) * (size - 10) * 0.5 - text_width*0.5;
					c_x1 = CLIP(c_x1, x->m_box.b_rect.left + 5, x->m_box.b_rect.right - text_width-5);
					
					c_y1 = top  + (1 - x->coord[i].y) * (size - 10) * 0.5 + 10 + x->fontsize;
					c_y1 = (c_y1 > top + size - 5 ? c_y1 - 0 - x->fontsize*2.5 : c_y1);

					MoveTo(c_x1, c_y1);
					DrawText(c, 0, strlen(c));
				}
			}
		}
		
		// draw selection rectangle
		if(x->sel_rect)
		{
		
			RGBForeColor(&x->rect_color);
	
			if(x->rectangle[0] < x->rectangle[2])
			{
				s_x1 = x->rectangle[0];
				s_x2 = x->rectangle[2];
			}
			else
			{
				s_x1 = x->rectangle[2];
				s_x2 = x->rectangle[0];
			}
			if(x->rectangle[1] < x->rectangle[3])
			{	
				s_y1 = x->rectangle[1];
				s_y2 = x->rectangle[3];
			}
			else
			{
				s_y1 = x->rectangle[3];
				s_y2 = x->rectangle[1];
			}
		
			SetRect(&r, s_x1, s_y1, s_x2, s_y2);
			FrameRect(&r);
		}

		// zoom doesn't apply to the white boxes
		left = x->m_box.b_rect.left;
	 	top = x->m_box.b_rect.top;
		size = x->h_size;
		
		// draw white box "set no..."
		if(x->new_number)
		{
			sprintf(c, "set no %d", x->new_number);

			XQT_TextSize(x->fontsize * 11/9);
			XQT_TextFont(x->fontnum);
			
			text_width = TextWidth(c, 0, strlen(c)); 
			
			RGBForeColor(&WHITE);
			SetRect(&r, left+ size*0.5 - text_width*0.7,
						top + size*0.5 - x->fontsize*1.6,
						left+ size*0.5 + text_width*0.7,
						top + size*0.5 + x->fontsize*1.6);
			PaintRect(&r);
			
			RGBForeColor(&BLACK);		
			MoveTo( left + size*0.5 - text_width*0.5,
					top  + size*0.5 +	x->fontsize*0.5);

			DrawText(c, 0, strlen(c));
		}
		
		// draw white box "store snapshot no..."
		if(x->new_snapshot)
		{			
			if(x->snapshot_num == 0)
			{
				XQT_TextSize(x->fontsize * 11/9);
				XQT_TextFont(x->fontnum);

				sprintf(c, "store snapshot ...");
				text_width = TextWidth(c, 0, strlen(c)); 

				RGBForeColor(&WHITE);
				SetRect(&r, left+ size*0.5 - text_width*0.7,
							top + size*0.5 - x->fontsize*1.4,
							left+ size*0.5 + text_width*0.7,
							top + size*0.5 + x->fontsize*1.4);
				PaintRect(&r);
							
				RGBForeColor(&BLACK);	
				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*0.5);

				DrawText(c, 0, strlen(c));
			}
			
			else
			{		
				XQT_TextSize(x->fontsize * 11/9);
				XQT_TextFont(x->fontnum);

				sprintf(c, "store snapshot ...");
				text_width = TextWidth(c, 0, strlen(c)); 

				RGBForeColor(&WHITE);
				SetRect(&r, left+ size*0.5 - text_width*0.7,
							top + size*0.5 - x->fontsize*1.4,
							left+ size*0.5 + text_width*0.7,
							top + size*0.5 + x->fontsize*3);
				PaintRect(&r);
			
				RGBForeColor(&BLACK);	

				sprintf(c, "store snapshot %ld", x->snapshot_num);
				text_width = TextWidth(c, 0, strlen(c)); 

				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*0.5);
				DrawText(c, 0, strlen(c));

				text_width = TextWidth(ok, 0, strlen(ok)); 

				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*2);
				DrawText(ok, 0, strlen(ok));
			}
		}
		
		// draw white box "recall snapshot no..."
		if(x->rcl_snapshot)
		{		
			MoveTo(size*0.5-49, size*0.5+4);
			
			if(x->snapshot_num == 0)
			{
				XQT_TextSize(x->fontsize * 11/9);
				XQT_TextFont(x->fontnum);

				sprintf(c, "recall snapshot ...");
				text_width = TextWidth(c, 0, strlen(c)); 

				RGBForeColor(&WHITE);
				SetRect(&r, left+ size*0.5 - text_width*0.7,
							top + size*0.5 - x->fontsize*1.4,
							left+ size*0.5 + text_width*0.7,
							top + size*0.5 + x->fontsize*1.4);
				PaintRect(&r);
			
				RGBForeColor(&BLACK);	

				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*0.5);
				DrawText(c, 0, strlen(c));
			}
			
			else
			{				
				XQT_TextSize(x->fontsize * 11/9);
				XQT_TextFont(x->fontnum);

				sprintf(c, "recall snapshot ...");
				text_width = TextWidth(c, 0, strlen(c)); 

				RGBForeColor(&WHITE);
				SetRect(&r, left+ size*0.5 - text_width*0.7,
							top + size*0.5 - x->fontsize*1.4,
							left+ size*0.5 + text_width*0.7,
							top + size*0.5 + x->fontsize*3);
				PaintRect(&r);
			
				RGBForeColor(&BLACK);	

				sprintf(c, "recall snapshot %ld", x->snapshot_num);
				text_width = TextWidth(c, 0, strlen(c)); 

				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*0.5);
				DrawText(c, 0, strlen(c));

				text_width = TextWidth(ok, 0, strlen(ok)); 

				MoveTo( left + size*0.5 - text_width*0.5,
						top  + size*0.5 +	x->fontsize*2);
				DrawText(ok, 0, strlen(ok));
			}
		}

	// show frame when highlited
	if(x->m_box.b_hilited)
	{
		RGBForeColor(&BLACK);
		SetRect(&r, left+1, top+1, right-1, bottom-1);
		FrameRect(&r);
	}
				
	// restore everything...
	RGBForeColor(&BLACK);

#ifdef MAC_VERSION
	SetClip(old); 
	DisposeRgn(old); 
	DisposeRgn(boxclip);
#else  // Windows
	// restore previous drawing and copy offscreen image on-screen
	SetGWorld((CGrafPtr)currPort, currDevice);
	CopyBits(XQT_GetPortBitMapForCopyBits((CGrafPtr)offPort), XQT_GetPortBitMapForCopyBits((CGrafPtr)currPort), &offrect, &offrect, srcCopy, NIL);
#endif	
}

//___________________________________________________________________________________________________________________________

// build a linked list of pointers to data of additional graphics

void monitor_add_graph_new(t_monitor *x, short n, RGBColor *color, double **data, long *number)
{		
	add_gr *pointer = x->additional_graphics, *newpointer;
	short size;
		
	size = sizeof(add_gr);
		
	newpointer = (add_gr *)sysmem_newptr(sizeof(add_gr));
	
	newpointer->type = n;
	newpointer->color = color;
	newpointer->data = data;
	newpointer->next = 0;
	if(n == 2)
		newpointer->number = number;
	
	if(!pointer)	// is first element of the linked list
	{
		x->additional_graphics = newpointer;
		newpointer->prev = 0;
		return;
	}
	
	while (pointer->next)
	{	
		pointer = pointer->next;
	}
	
	pointer->next = newpointer;
	newpointer->prev = pointer;
}

void monitor_add_graph_remove(t_monitor *x, void **data)
{
	add_gr *pointer = x->additional_graphics;
		
	if(pointer->data == (double **)data) // is first element of linked list
	{
		x->additional_graphics = pointer->next;
		sysmem_freeptr(pointer);
		return;
	}
		
	while(pointer)
	{
		if(pointer->data == (double **)data)
		{
			if(pointer->next)
				pointer->next->prev = pointer->prev;
			pointer->prev->next = pointer->next;
			sysmem_freeptr(pointer);
			return;
		}
		pointer = pointer->next;
	}		
}


//___________________________________________________________________________________________________________________________

// coordinate I/O

void monitor_xyz_input(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short i, n;
	double input[3] = {0, 0, 0};
	
	if(av[0].a_type != A_LONG) return;
	if(av[0].a_w.w_long < 1 || av[0].a_w.w_long > MAXPOINTS) return;

	n = av[0].a_w.w_long - 1;
	
	if (x->coord[n].status == 0)		// if it is a new point
	{
		x->coord[n].status = 1;
		x->coord[n].sel = 0;
		sprintf(x->coord[n].name, "%ld", n+1);
	}
	
	for(i=1;i<ac;i++)
	{
		switch(av[i].a_type)
		{
			case A_FLOAT : input[i-1] = av[i].a_w.w_float; break;
			case A_LONG: input[i-1] = av[i].a_w.w_long; break;
			default: input[i-1] = 0;
		}
	}
				
	x->coord[n].x = input[0];
	x->coord[n].y = input[1];
	x->coord[n].z = input[2];
	
	monitor_cartopol(&x->coord[n]);				// conversion xyz -> aed
		
	monitor_output(x, n);
		
	qelem_set(x->m_qelem);
}

void monitor_aed_input(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short i, n;
	double input[3] = {0, 0, 0};
	
	if(av[0].a_type != A_LONG) return;
	if(av[0].a_w.w_long < 1 || av[0].a_w.w_long > MAXPOINTS) return;

	n = av[0].a_w.w_long - 1;
	
	if (x->coord[n].status == 0)		// if it is a new point
	{
		x->coord[n].status = 1;
		x->coord[n].sel = 0;
		sprintf(x->coord[n].name, "%ld", n+1);
	}
	
	for(i=1;i<ac;i++)
	{
		switch(av[i].a_type)
		{
			case A_FLOAT : input[i-1] = av[i].a_w.w_float; break;
			case A_LONG: input[i-1] = av[i].a_w.w_long; break;
			default: input[i-1] = 0;
		}
	}
				
	x->coord[n].a = input[0];
	x->coord[n].e = input[1];
	x->coord[n].d = input[2];

		
	monitor_poltocar(&x->coord[n]);				// conversion aed -> xyz

	monitor_output(x, n);

	qelem_set(x->m_qelem);
}

void monitor_set_input(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short i, n;
	double input[3] = {0, 0, 0};
	
	if(av[0].a_w.w_sym != gensym("aed") && av[0].a_w.w_sym != gensym("xyz"))
	{
		post("ambimonitor: bad arguments for message \"set\"");
		return;
	}

	
	if(av[1].a_type != A_LONG) return;
	if(av[1].a_w.w_long < 1 || av[1].a_w.w_long > MAXPOINTS) return;

	n = av[1].a_w.w_long - 1;
		
	if (x->coord[n].status == 0)		// if it is a new point
	{
		x->coord[n].status = 1;
		x->coord[n].sel = 0;
		sprintf(x->coord[n].name, "%ld", n+1);
	}
		
	if (av[0].a_w.w_sym == gensym("xyz"))
	{
		for(i=2;i<ac;i++)
		{
			switch(av[i].a_type)
			{
				case A_FLOAT : input[i-2] = av[i].a_w.w_float; break;
				case A_LONG: input[i-2] = av[i].a_w.w_long; break;
				default: input[i-2] = 0;
			}
		}
				
		x->coord[n].x = input[0];
		x->coord[n].y = input[1];
		x->coord[n].z = input[2];
	
		monitor_cartopol(&x->coord[n]);				// conversion xyz -> aed
	}
		
	else
	{
		for(i=2;i<ac;i++)
		{
			switch(av[i].a_type)
			{
				case A_FLOAT : input[i-2] = av[i].a_w.w_float; break;
				case A_LONG: input[i-2] = av[i].a_w.w_long; break;
				default: input[i-2] = 0;
			}
		}
				
		x->coord[n].a = input[0];
		x->coord[n].e = input[1];
		x->coord[n].d = input[2];
	
		monitor_poltocar(&x->coord[n]);				// conversion aed -> xyz
	}
	
	qelem_set(x->m_qelem);
}

void monitor_output_coord(t_monitor *x, short n)
{
	monitor_output(x,n);
	qelem_set(x->m_qelem);
}

void monitor_output(t_monitor *x, short n)
{
	t_atom output[5];
	
	SETLONG (output,   n + 1 + x->offset);
	SETFLOAT(output+1, x->coord[n].x);
	SETFLOAT(output+2, x->coord[n].y);
	SETFLOAT(output+3, x->coord[n].z);
	SETLONG (output+4, x->coord[n].status);

	outlet_anything(x->m_outlet2, symbol_xyz, 5, output);
	
	SETFLOAT(output+1, x->coord[n].a);
	SETFLOAT(output+2, x->coord[n].e);
	SETFLOAT(output+3, x->coord[n].d);

	outlet_anything(x->m_outlet1, symbol_aed, 5, output);
}

//___________________________________________________________________________________________________________________________

// handling points

void monitor_rename(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short number = av[0].a_w.w_long;
	
	if(x->coord[number-1].status == 0)
	{
		error("ambimonitor: point %ld doesn't exist...", number);
		return;
	}
	
	if(ac < 2)
	{
		sprintf(x->coord[number-1].name, "%ld", number);
		qelem_set(x->m_qelem);
		return;
	}

	switch (av[1].a_type)
	{
		case A_LONG:
			sprintf(x->coord[number-1].name, "%ld", av[1].a_w.w_long);
			break;
		case A_SYM:
			strcpy(x->coord[number-1].name, av[1].a_w.w_sym->s_name);
			break;
	}
	qelem_set(x->m_qelem);
}

void monitor_clear(t_monitor *x)
{
	short i;
	
	for(i=0;i<MAXPOINTS;i++)
	{
		x->coord[i].active = 0;
		if(x->coord[i].status)
		{
			x->coord[i].status = 0;
			monitor_output(x,i);
		}
	}	
	qelem_set(x->m_qelem);
}

void monitor_delete(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	short i, number;
	
	for(i=0;i<ac;i++)
	{
		if(av[i].a_type == A_LONG)
		{
			number = av[i].a_w.w_long - 1;
			if(x->coord[number].status == 1)
			{
				x->coord[number].status = 0;
				x->coord[number].sel = 0;
				monitor_output(x,number);
			}
		}
	}
	qelem_set(x->m_qelem);
}

void monitor_dump(t_monitor *x)
{
	short i;
	
	for(i=0;i<MAXPOINTS;i++)
	{
		if(x->coord[i].status)
			monitor_output(x,i);
	}	
}

void monitor_offset(t_monitor *x, short n)
{
	if(n != x->offset) patcher_dirty (x->patcher);	
	x->offset = n;
}

//___________________________________________________________________________________________________________________________

// zoom

void monitor_zoom(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	// set defaults
	x->zoom_factor = 1;
	x->zoom_focal_point_x = x->zoom_focal_point_y = 0;
	
	if(ac > 0)
	{
		switch(av[0].a_type)
		{
			case A_FLOAT :	x->zoom_factor = av[0].a_w.w_float; break;
			case A_LONG:	x->zoom_factor = av[0].a_w.w_long; break;
		}
		x->zoom_factor = CLIP(x->zoom_factor, 1, 95);
	}

	if(ac > 1)
		x->zoom_focal_point_x = CLIP(av[1].a_w.w_float, -1, 1);
	if(ac > 2)
		x->zoom_focal_point_y = CLIP(av[2].a_w.w_float, -1, 1);
	
	qelem_set(x->m_qelem);
}

//___________________________________________________________________________________________________________________________

// object name

void monitor_name(t_monitor *x) 
{ 
	t_box *b; 
	t_symbol *s;
		
	// a pointer to the object is stored in the s_thing field of a t_symbol
	
	b = x->patcher->p_box;
	while(b)
	{	
		if(patcher_boxname(x->patcher,b,&s) && b->b_firstin == x)
		// b->b_firstin is the address of the object the box b contains
		{ 			
			gensym(x->name)->s_thing = 0;					// remove old reference	
	
			strcpy(x->name, s->s_name);
			gensym(x->name)->s_thing = (t_object *)(long)x;	// set new reference	
						
			return;
		}
		b=b->b_next;
	} 
} 

//___________________________________________________________________________________________________________________________

// display options

void monitor_mode(t_monitor *x, short n)
{
	short left = x->m_box.b_rect.left;
	short right = x->m_box.b_rect.right;
		
	short hsize = right - left;
	short vsize;
	
	if(n != x->mode) patcher_dirty (x->patcher);
		
	x->mode = CLIP(n, 0, 2);
	
	
	switch(x->mode)
	{
		case 0:
			vsize = hsize; break;
		case 1:
			vsize = hsize * 1.5 + 4.5; break;
		case 2:
			vsize = hsize * 2; break;
	}

	box_size(&x->m_box, hsize, vsize);
	
#ifdef WIN_VERSION
	monitor_alloc_offscreen(x);
#endif
}

void monitor_size(t_monitor *x, short n)
{	
	short hsize, vsize;
	
	n = (n < 100 ? 100 : n);
	hsize = n;
	
	switch (x->mode)
	{
		case 0:
		vsize = hsize; break;	
		case 1:
		vsize = hsize * 1.5 + 4.5; break;
		case 2:
		vsize = hsize * 2; break;
	}
	
	box_size(&x->m_box, hsize, vsize);
}

void monitor_numbers(t_monitor *x, long n)
{
	if(n != x->numbers) patcher_dirty (x->patcher);
	x->numbers = n;
	qelem_set(x->m_qelem);
}

void monitor_coordinates(t_monitor *x, long n)
{
	if(n != x->coordinates) patcher_dirty (x->patcher);
	x->coordinates = n;
	qelem_set(x->m_qelem);
}

void monitor_lines(t_monitor *x, long n)
{
	if(n != x->lines) patcher_dirty (x->patcher);
	x->lines = n;
	qelem_set(x->m_qelem);
}

void monitor_grid(t_monitor *x, long n)
{
	if(n != x->grid) patcher_dirty (x->patcher);
	x->grid = n;
	qelem_set(x->m_qelem);
}

void monitor_gridunit_xyz(t_monitor *x, double n)
{
	x->gridunit_xyz = (n > 0 ? n : 1);
	qelem_set(x->m_qelem);
}

void monitor_gridunit_ae(t_monitor *x, long n)
{
	x->gridunit_ae = (n >= 0 ? n : 0);
	qelem_set(x->m_qelem);
}

void monitor_gridunit_d(t_monitor *x, double n)
{
	x->gridunit_d = (n * 0.1 > 0 ? n * 0.1 : 1);
	qelem_set(x->m_qelem);
}

void monitor_bfont(t_monitor *x, short size, short fontnum)   // not yet in operation...
{		
	x->fontsize = (size == -1 ? x->fontsize : size);
	x->fontnum = (fontnum == -1 ? x->fontnum : fontnum);
	
	qelem_set(x->m_qelem);
}

//___________________________________________________________________________________________________________________________

// mouse manipulation

void monitor_local(t_monitor *x, long n)
{
	if(n != x->local) patcher_dirty (x->patcher);
	x->local = (n == 0 ? 0 : 1);
}	

void monitor_click(t_monitor *x, Point pt, short modifiers)
{
	short i, j, hit;
	
	short left = x->m_box.b_rect.left;
	short top = x->m_box.b_rect.top;
		
	short size = x->h_size; //right - left;
	
	if(x->local == 0) return;
		
	x->m_box.b_pending = 1; // set pending flag (object doesn't receive "enter" message without it...)
			
	if(x->new_number) monitor_new_point(x, pt);
	
	// calculate zoom view (only if mode == 0)
	if(x->mode == 0)
	{
		size = size * x->zoom_factor;	
		left = left - x->zoom_focal_point_x * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
		top  = top  + x->zoom_focal_point_y * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
	}
	
	hit = 0;
	
	for(i=0;i<MAXPOINTS;i++)
	{
		// mouse hits xy location
		if(x->coord[i].status == 1	&& pt.h - left < (x->coord[i].x + 1) *  0.5 * (size - 10) + 5 + RADIUS
									&& pt.h - left > (x->coord[i].x + 1) *  0.5 * (size - 10) + 5 - RADIUS
							 		&& pt.v - top  < (x->coord[i].y - 1) * -0.5 * (size - 10) + 5 + RADIUS
							 		&& pt.v - top  > (x->coord[i].y - 1) * -0.5 * (size - 10) + 5 - RADIUS)
		{
				// reset all previously activated numbers unless shift key is depressed
				if(modifiers != 512 && x->coord[i].active == 0) for(j=0;j<MAXPOINTS;j++) x->coord[j].active = 0;

				if(modifiers != 512)
					x->coord[i].active = 1;
				else
					x->coord[i].active = 1 - x->coord[i].active;

				hit = 1;
				x->h_mouse = pt.h;
				x->v_mouse = pt.v;
				wind_drag((method)monitor_drag_xy, x, pt);
				break;

		}	
		// mouse hits xz location
		if(x->coord[i].status == 1	&& pt.h - left < (x->coord[i].x + 1) *  0.5 * (size - 10) + 5 + RADIUS
									&& pt.h - left > (x->coord[i].x + 1) *  0.5 * (size - 10) + 5 - RADIUS
							 		&& pt.v - top - size < (x->coord[i].z - 1) * -0.5 * (size - 10) + 5 + RADIUS
							 		&& pt.v - top - size > (x->coord[i].z - 1) * -0.5 * (size - 10) + 5 - RADIUS)
		{					 
				// reset all previously activated numbers unless shift key is depressed
				if(modifiers != 512 && x->coord[i].active == 0) for(j=0;j<MAXPOINTS;j++) x->coord[j].active = 0;

				if(modifiers != 512)
					x->coord[i].active = 1;
				else
					x->coord[i].active = 1 - x->coord[i].active;

				hit = 1;
				x->h_mouse = pt.h;
				x->v_mouse = pt.v;
				wind_drag((method)monitor_drag_xz, x, pt);
				break;
		}	
	}
	if(!hit)
	{
		
		
		for(i=0;i<MAXPOINTS;i++)
		{
			// reset all activated numbers unless shift key is depressed
			if(modifiers != 512) x->coord[i].active = 0;
			// copy active status to "sel" array (used in "monitor_sel_region" method)
			x->coord[i].sel = x->coord[i].active;
		}
		
		x->rectangle[0] = pt.h;
		x->rectangle[1] = pt.v;
		x->rectangle[2] = pt.h;
		x->rectangle[3] = pt.v;
		x->sel_rect = 1;
		wind_drag((method)monitor_sel_region, x, pt);
	}
	
	qelem_set(x->m_qelem);
}

void monitor_drag_xy(t_monitor *x, Point pt, short but)
{
	double h_delta, v_delta;
	short i, selected, f;
		
	short left = x->m_box.b_rect.left;
	short top = x->m_box.b_rect.top;
		
	short size = x->h_size;

	// calculate zoom view (only if mode == 0)
	if(x->mode == 0)
	{
		size = size * x->zoom_factor;	
		left = left - x->zoom_focal_point_x * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
		top  = top  + x->zoom_focal_point_y * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
	}
		
	f = 1;
	
	h_delta = (x->h_mouse - pt.h) *  2 / (double)size;
	v_delta = (x->v_mouse - pt.v) *  2 / (double)size;
	
	if (!but)		
		return; // if there's no mouse button being held down, then stop dragging and exit
	
	for(i=0;i<MAXPOINTS;i++)
	{
		if(x->coord[i].active == 1 && (x->coord[i].x - h_delta > 1. || x->coord[i].x - h_delta < -1. || 
							 x->coord[i].y + v_delta > 1. || x->coord[i].y + v_delta < -1.))
		{f = 0; break;}
	}

	if(f)
	{
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active == 1)
			{
				x->coord[i].x = x->coord[i].x - h_delta;
				x->coord[i].y = x->coord[i].y + v_delta;
			
				monitor_cartopol(&x->coord[i]);				// conversion xyz -> aed
				
				monitor_output(x,i);
			}
		}
	
	x->h_mouse = pt.h;
	x->v_mouse = pt.v;

	qelem_set(x->m_qelem);
	}
}

void monitor_drag_xz(t_monitor *x, Point pt, short but)
{
	double h_delta, v_delta, z_min;
	short i, f;
	
	short left = x->m_box.b_rect.left + 1;
	short top = x->m_box.b_rect.top + 1;
	short right = x->m_box.b_rect.right - 1;
	short bottom = x->m_box.b_rect.bottom - 1;
		
	short hsize = right - left;
	
	z_min = (x->mode == 1 ? 0. : -1.);
	
	f = 1;
	
	h_delta = (x->h_mouse - pt.h) *  2 / (double)hsize;
	v_delta = (x->v_mouse - pt.v) * -2 / (double)hsize;
	
	if (!but)		
		return; // if there's no mouse button being held down, then stop dragging and exit
	
	for(i=0;i<MAXPOINTS;i++)
	{
		if(x->coord[i].active == 1 && (x->coord[i].x - h_delta > 1. || x->coord[i].x - h_delta < -1. || 
							 x->coord[i].z - v_delta > 1. || x->coord[i].z - v_delta < z_min))
		{f = 0; break;}
	}

	if(f)
	{
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active == 1)
			{
				x->coord[i].x = x->coord[i].x - h_delta;
				x->coord[i].z = x->coord[i].z - v_delta;
			
				monitor_cartopol(&x->coord[i]);				// conversion xyz -> aed
				
				monitor_output(x,i);
			}
		}
	
	x->h_mouse = pt.h;
	x->v_mouse = pt.v;

	qelem_set(x->m_qelem);
	}
}

void monitor_sel_region(t_monitor *x, Point pt, short but)
{
	short i;
	short xval, yval, zval;		// on screen
	
	short left = x->m_box.b_rect.left;
	short top = x->m_box.b_rect.top + 1;
		
	short size = x->h_size;

	// calculate zoom view (only if mode == 0)
	if(x->mode == 0)
	{
		size = size * x->zoom_factor;	
		left = left - x->zoom_focal_point_x * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
		top  = top  + x->zoom_focal_point_y * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
	}
		
	if (!but)
	{
		x->sel_rect = 0;	
		qelem_set(x->m_qelem);
		return; // if there's no mouse button being held down, then stop dragging and exit
	}
	
	x->rectangle[2] = pt.h;
	x->rectangle[3] = pt.v;
	
	for(i=0;i<MAXPOINTS;i++)
	{
		xval = left + (1 + x->coord[i].x) * size * 0.5;
		yval = top  + (1 - x->coord[i].y) * size * 0.5;
		zval = top  + (1 - x->coord[i].z) * size * 0.5 + size;
		
		x->coord[i].active = x->coord[i].sel;
		
		if(xval >= (x->rectangle[0] <= x->rectangle[2] ? x->rectangle[0] : x->rectangle[2]) &&
		   xval <= (x->rectangle[0] >= x->rectangle[2] ? x->rectangle[0] : x->rectangle[2]) &&
		   yval >= (x->rectangle[1] <= x->rectangle[3] ? x->rectangle[1] : x->rectangle[3]) &&
		   yval <= (x->rectangle[1] >= x->rectangle[3] ? x->rectangle[1] : x->rectangle[3]) &&
		   x->coord[i].status != 0)
			 x->coord[i].active = 1 - x->coord[i].sel;
			 
		if(xval >= (x->rectangle[0] <= x->rectangle[2] ? x->rectangle[0] : x->rectangle[2]) &&
		   xval <= (x->rectangle[0] >= x->rectangle[2] ? x->rectangle[0] : x->rectangle[2]) &&
		   zval >= (x->rectangle[1] <= x->rectangle[3] ? x->rectangle[1] : x->rectangle[3]) &&
		   zval <= (x->rectangle[1] >= x->rectangle[3] ? x->rectangle[1] : x->rectangle[3]) &&
		   x->coord[i].status != 0)
			 x->coord[i].active = 1 - x->coord[i].sel;
	}
	
	qelem_set(x->m_qelem);
}

void monitor_enter(t_monitor *x)	// user highlights another box or clicks outside the box
{
	short i;
	
	x->rcl_snapshot = 0;
	x->new_snapshot = 0;
	x->new_number = 0;
	
	// reset all activated numbers
	for(i=0;i<MAXPOINTS;i++)
			x->coord[i].active = 0;
}


//___________________________________________________________________________________________________________________________

// keyboard commands

void monitor_enablekeys(t_monitor *x, long n)
{
	if(n != x->enablekeys) patcher_dirty (x->patcher);
	x->enablekeys = (n == 0 ? 0 : 1);
}

void monitor_key(t_monitor *x, short key, short mod)
{
	short i, number;
	t_atom n;
	
//	post("%d", key);
	
	if (x->enablekeys == 0) return;					// keyboard disabled
			
	if (key == 8)									// delete key
	{									
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active == 1)
			{
				x->coord[i].status = 0;
				x->coord[i].active = 0;
				monitor_output(x,i);
			}
		}
	}
		
	if (key >= 48 && key <= 57)								// keys no 0 - 9
	{
		if(x->new_snapshot == 0 && x->rcl_snapshot == 0)	// (select point)
		{
			if(mod != 512) x->first_digit = 0;
			
			number = key - 49 + x->first_digit * 10;
			
			if(number > MAXPOINTS - 1)
			{
				qelem_set(x->m_qelem);
				x->new_number = 0;
				x->first_digit = 0;
				return;
			}
			
			if(number > 8 || mod != 512)
			{
				if(x->coord[number].status == 1)
				{x->coord[number].active = 1 - x->coord[number].active;x->new_number = 0;}
				else if(x->new_number == number+1) x->new_number = 0;
				else x->new_number = number+1;
			}
		}
		
		else								// (recall or store snapshot)
		{			
			if(mod != 512) x->first_digit = 0;
			
			number = key - 48 + x->first_digit * 10;
		
			if(number > 9 || mod != 512)
				x->snapshot_num = number;
		}
		
		if(mod == 512) x->first_digit = key - 48;
	}

	if(x->local == 0) x->new_number = 0;	// can't set new points without local enabled

	if (key == 68 || key == 100)					// "d" and "D" key
	{
		for(i=0;i<MAXPOINTS;i++) x->coord[i].active = 0;
	}
		
	if (key == 97 || key == 65)						// "a" and "A" key
	{
		for(i=0;i<MAXPOINTS;i++)
			if(x->coord[i].status == 1) x->coord[i].active = 1;
	}
	
	if (key == 115)									// "s" key (select snapshot)
	{
		x->new_number = 0;
		x->new_snapshot = 0;
		x->snapshot_num = 0;
		x->rcl_snapshot = 1 - x->rcl_snapshot;
	}
	
	if (key == 83)									// "S" key (+shift, store snapshot)
	{
		x->new_number = 0;
		x->first_digit = 0;
		x->rcl_snapshot = 0;
		x->snapshot_num = 0;
		x->new_snapshot = 1 - x->new_snapshot;
	}
	
	if (key == 3 || key == 13)						// enter and return
	{
		if(x->new_snapshot)
		{
			SETLONG(&n,x->snapshot_num);
			monitor_store(x,0L,1,&n);
		}
		if(x->rcl_snapshot)
			monitor_int(x,x->snapshot_num);
		x->rcl_snapshot = 0;
		x->snapshot_num = 0;
		x->new_snapshot = 0;
	}
			
	if (key >= 28 && key <= 31)						// arrow keys
		monitor_nudge(x,key,mod);
		
	if (key == 43)											// zoom
		x->zoom_factor = CLIP(x->zoom_factor + 0.05, 1, 95);
	if (key == 45)
		x->zoom_factor = CLIP(x->zoom_factor - 0.05, 1, 95);
	if (key == 61)
	{
		x->zoom_factor = 1.;
		x->zoom_focal_point_x = x->zoom_focal_point_y = 0;
	}
	
	qelem_set(x->m_qelem);

}

//___________________________________________________________________________________________________________________________

// nudge selected points

void monitor_nudge(t_monitor *x, short n, short mod)
{
	short i;
	
#ifdef MAC_VERSION
	if(mod == 2048)		// alt-key
#else
	if(mod == 1152)		// caps lock on Windows
#endif
	{	
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active)
			{
				switch(n)
				{
					case 28:									// rotate CCW
						x->coord[i].a -= x->nudgeunit_a;break;
					case 29:									// rotate CW
						x->coord[i].a += x->nudgeunit_a;break;
					case 30:									// radial move
						x->coord[i].d += x->nudgeunit_d;break;
					case 31:
						x->coord[i].d -= x->nudgeunit_d;
						x->coord[i].d = (x->coord[i].d > 0. ? x->coord[i].d : 0);
						break;
				}

				monitor_poltocar(&x->coord[i]);				// conversion aed -> xyz

				monitor_output(x, i);
			}
		}
	}
#ifdef MAC_VERSION
	if(mod == 512)		// shift-key
#else
	if(mod == 640)
#endif
	{
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active)
			{
				switch(n)
				{
					case 28:
						x->coord[i].x -= x->nudgeunit_xyz;break;	// nudge in y direction
					case 29:
						x->coord[i].x += x->nudgeunit_xyz;break;
					case 30:
						x->coord[i].z += x->nudgeunit_xyz;break;	// nudge in z direction
					case 31:
						x->coord[i].z -= x->nudgeunit_xyz;break;
				}

				monitor_cartopol(&x->coord[i]);				// conversion xyz -> aed

				monitor_output(x, i);
			}
		}
	}
#ifdef MAC_VERSION
	if(mod == 0)		// no modifier key
#else
	if(mod == 128)
#endif
	{
		for(i=0;i<MAXPOINTS;i++)
		{
			if(x->coord[i].active)
			{
				switch(n)
				{
					case 28:
						x->coord[i].x -= x->nudgeunit_xyz;break;	// nudge in y direction
					case 29:
						x->coord[i].x += x->nudgeunit_xyz;break;
					case 30:
						x->coord[i].y += x->nudgeunit_xyz;break;	// nudge in x direction
					case 31:
						x->coord[i].y -= x->nudgeunit_xyz;break;
				}

				monitor_cartopol(&x->coord[i]);				// conversion xyz -> aed

				monitor_output(x, i);
			}
		}
	}
}

void monitor_nudgeunit_xyz(t_monitor *x, double n)
{
	x->nudgeunit_xyz = abs(n);
}

void monitor_nudgeunit_a(t_monitor *x, double n)
{
	x->nudgeunit_a = abs(n);
}

void monitor_nudgeunit_d(t_monitor *x, double n)
{
	x->nudgeunit_d = abs(n);
}

//___________________________________________________________________________________________________________________________

// set a new point

void monitor_new_point(t_monitor *x, Point pt)
{
	short left = x->m_box.b_rect.left;
	short top = x->m_box.b_rect.top;
		
	short size = x->h_size;

	double xval, yval, zval;

	// calculate zoom view (only if mode == 0)
	if(x->mode == 0)
	{
		size = size * x->zoom_factor;	
		left = left - x->zoom_focal_point_x * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
		top  = top  + x->zoom_focal_point_y * size * 0.5 - (x->zoom_factor - 1) * x->h_size * 0.5;
	}

	xval = -1 + (pt.h-left) * 2 / (double)size;
	yval = (pt.v-top) * -2 / (double)size + 1;
	zval = (pt.v-top - size) * -2 / (double)size + 1;

	if(yval > -1.)
	{
		x->coord[x->new_number - 1].x = xval;
		x->coord[x->new_number - 1].y = yval;
		x->coord[x->new_number - 1].z = 0;
	}
	else
	{
		x->coord[x->new_number - 1].x = xval;
		x->coord[x->new_number - 1].y = 0;
		x->coord[x->new_number - 1].z = zval;
	}
	
		x->coord[x->new_number - 1].status = 1;
		
		sprintf(x->coord[x->new_number - 1].name, "%ld", x->new_number);
		
		monitor_cartopol(&x->coord[x->new_number - 1]);				// conversion xyz -> aed
		
		monitor_output(x, x->new_number - 1);
		
		x->new_number = 0;
		x->first_digit = 0;
		
		qelem_set(x->m_qelem);
}

//___________________________________________________________________________________________________________________________

// colors

void setcolor(RGBColor *color, short ac, t_atom *av)
{
	if(av[0].a_type == A_LONG)
		color->red = CLIP(av[0].a_w.w_long, 0, 255)  * 255; 
	else color->red = 0;
	if(ac > 0 && av[1].a_type == A_LONG)
		color->green = CLIP(av[1].a_w.w_long, 0, 255) * 255;
	else color->green = 0;
	if(ac > 1 && av[2].a_type == A_LONG)
		color->blue = CLIP(av[2].a_w.w_long, 0, 255) * 255;
	else color->blue = 0;
}

void monitor_set_point_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->point_color, ac, av);
	qelem_set(x->m_qelem);
}

void monitor_set_name_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->name_color, ac, av);
	qelem_set(x->m_qelem);
}

void monitor_set_coord_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->coord_color, ac, av);
	qelem_set(x->m_qelem);
}
	
void monitor_set_line_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->line_color, ac, av);
	qelem_set(x->m_qelem);
}

void monitor_set_circle_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->circle_color, ac, av);
	qelem_set(x->m_qelem);
}

void monitor_set_background_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->background_color, ac, av);
	qelem_set(x->m_qelem);
}

void monitor_set_grid_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->grid_color, ac, av);
	qelem_set(x->m_qelem);
}
	
void monitor_set_hi_grid_color(t_monitor *x, t_symbol *s, short ac, t_atom *av)
{
	setcolor(&x->hi_grid_color, ac, av);
	qelem_set(x->m_qelem);
}

//___________________________________________________________________________________________________________________________

// mathematics...


// cartesian <-> polar conversion

void monitor_cartopol(ambi *coords)		// xyz to aed
{
	coords->a = atan2(coords->x, coords->y) / PI * 180;
	coords->e = atan2(coords->z, pow(pow(coords->y,2)+pow(coords->x,2),0.5)) / PI * 180;
	coords->d = pow(pow(coords->y,2)+pow(coords->x,2)+pow(coords->z,2), 0.5) * 10;
}

void monitor_poltocar(ambi *coords)		// aed to xyz
{
	coords->x = cos((90 - coords->a) / 180 * PI) * cos(coords->e / 180 * PI) * coords->d * 0.1;
	coords->y = sin((90 - coords->a) / 180 * PI) * cos(coords->e / 180 * PI) * coords->d * 0.1;
	coords->z = sin(coords->e / 180 * PI) * coords->d * 0.1;
}

//___________________________________________________________________________________________________________________________

// utilities

void monitor_version(void)
{
	post("ambimonitor    -    Philippe Kocher/ICST Zurich    -    � 2006");
	post("    version %s compiled %s %s", __VERSION__, __DATE__, __TIME__);
}

void monitor_report(t_monitor *x)
{
	monitor_version();
}	

void monitor_assist(t_monitor *x, void *b, long m, long a, char *s)
{
	if (m == ASSIST_INLET)
	{
		switch (a)
		{	
		case 0:
			sprintf(s, "coordinates, messages");
			break;
		}
	}
	else
	{
		switch (a)
		{
			case 0:
				sprintf(s, "aed coordinate output (index, A, E, D, status)");
				break;
			case 1:
				sprintf(s, "xyz coordinate output (index, X, Y, Z, status)");
				break;
		}
	}
}

void monitor_psave(t_monitor *x, void *buf)
{
	short hidden = x->m_box.b_hidden; 
 	Rect *r = &x->m_box.b_rect;
 	 	
 	if (hidden)
 	{ 
		binbuf_vinsert(buf,"ssssllllllllll",gensym("#P"),gensym("hidden"),  
		gensym("user"),gensym("ambimonitor"),
		(long)(r->left), 
		(long)(r->top),
		(long)(r->right - r->left), 
		(long)(r->bottom - r->top),
		(long)x->mode,
		(long)x->grid,
		(long)x->numbers,
		(long)x->coordinates,
		(long)x->lines,
		(long)x->offset);
	}
	else
	{ 
		binbuf_vinsert(buf,"sssllllllllll", gensym("#P"), gensym("user"), 
		gensym("ambimonitor"),  
		(long)(r->left),
		(long)(r->top), 
		(long)(r->right - r->left), 
		(long)(r->bottom - r->top),
		(long)x->mode,
		(long)x->grid,
		(long)x->numbers,
		(long)x->coordinates,
		(long)x->lines,
		(long)x->offset);
	}
	
	if(!x->local)
		binbuf_vinsert(buf, "ssl", gensym("#X"), gensym("local"), 0);

	if(!x->enablekeys)
		binbuf_vinsert(buf, "ssl", gensym("#X"), gensym("enablekeys"), 0);

		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb1"), x->point_color.red/255, x->point_color.green/255, x->point_color.blue/255);
		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb2"), x->name_color.red/255, x->name_color.green/255, x->name_color.blue/255);
		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb3"), x->coord_color.red/255, x->coord_color.green/255, x->coord_color.blue/255);
		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb4"), x->line_color.red/255, x->line_color.green/255, x->line_color.blue/255);

		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb5"), x->circle_color.red/255, x->circle_color.green/255, x->circle_color.blue/255);
		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb6"), x->background_color.red/255, x->background_color.green/255, x->background_color.blue/255);

		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb7"), x->grid_color.red/255, x->grid_color.green/255, x->grid_color.blue/255);
		binbuf_vinsert(buf, "sslll", gensym("#X"), gensym("rgb8"), x->hi_grid_color.red/255, x->hi_grid_color.green/255, x->hi_grid_color.blue/255);
}

void monitor_free(t_monitor *x)
{
	qelem_free(x->m_qelem); 			// free the queue element
	notify_free((t_object *)x);

	gensym(x->name)->s_thing = 0;		// remove pointer to this object

	monitor_remove_all(x);				// free memory used for snapshots

	box_free((t_box *)x);
}