/* 

	fileIO.c	write/read breakpoint trajectory to/from a XML file
				part of the ICST Ambisonics Tools

	Copyright (C) 2003 - 2006 ICST Zurich / Philippe Kocher
	
	http://www.icst.net
	

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
	
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
	
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    
	2006/06/18 Version 1.1	minor bugfixes, ported to PC
	2006/03/27 Version 1.0	initial release

*/

#include "ambicontrol.h"


// prototypes
void control_dowrite(t_control *x, t_symbol *s, short ac, t_atom *av);
void write_to_file(t_filehandle file, time_pos *pointer);

void control_doread(t_control *x, t_symbol *s, short ac, t_atom *av);
void read_from_file(t_control *x, t_filehandle file, char *filename);

short read_ambiscore(t_control *x, t_filehandle file);
short read_trajectory(t_control *x, t_filehandle file);
short read_breakpoint(t_filehandle file, time_pos *breakpoint);

short get_tag(t_filehandle file, char *tag, char *rem);
short get_data(t_filehandle file, char* data);

short file_getchar(t_filehandle file, char *c);
short white_space(char c);
void remove_space_from_string(char *str);
short string_to_number(char *name);
void string_to_triplet(char *string, double *coord_triplet);

//___________________________________________________________________________________________________________________________

// write breakpoints to a XML formatted file

void control_write(t_control *x, t_symbol *s)
{
	defer_low(x,(method)control_dowrite, s, 0, 0L);
}

void control_dowrite(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	t_filehandle file;
	char filename[64] = "trajectory.xml";
	short path;
	
	if (!s->s_name[0])
	{
		if (saveas_dialog(filename, &path, 0L))
			return;
	}
			
	else
	{
		strcpy(filename, s->s_name); 
		path = path_getdefault();
	} 

	if (path_createsysfile(filename, path, 'TEXT', &file))
	{
		error("%s: couldn't write trajectory to file \"%s\"", __EXTERNAL_NAME__, filename);
		return;
	}
		
	write_to_file(file, x->first_breakpoint);
	
	sysfile_close(file);
}

void write_to_file(t_filehandle file, time_pos *pointer)
{
	short i, err;
	long file_pos;
	long count;
	char c[128];
	
	sprintf(c, "<?xml version=\"1.0\" standalone=\"yes\" encoding=\"UTF-8\"?>\r\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
	
	sprintf(c, "<ambiscore version=\"1.0\">\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
	
// coordinate system definition
	sprintf(c, "\t<xyz-def handedness=\"right\" x-axis=\"right\" />\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);

	sprintf(c, "\t<trajectory>\r");
	count = strlen(c);
	err = sysfile_write(file, &count, c);

	while (pointer)
	{				
		sprintf(c, "\t\t<point>\r");
		count = strlen(c);
		err = sysfile_write(file, &count, c);
		
		sprintf(c, "\t\t\t<time>%ld</time>\r", pointer->time);
		count = strlen(c);
		err = sysfile_write(file, &count, c);

		sprintf(c, "\t\t\t<xyz>%f %f %f</xyz>\r\t\t</point>\r",		
					pointer->position.x, pointer->position.y, pointer->position.z);
		count = strlen(c);
		err = sysfile_write(file, &count, c);
		
		pointer = pointer->next;
	}

	sprintf(c, "\t</trajectory>\r</ambiscore>");
	count = strlen(c);
	err = sysfile_write(file, &count, c);
			
	sysfile_getpos(file, &file_pos);
	sysfile_seteof(file, file_pos);
}

//___________________________________________________________________________________________________________________________

// read breakpoints from a XML formatted file

void control_read(t_control *x, t_symbol *s)
{
	defer_low(x,(method)control_doread, s, 0, 0L);
}

void control_doread(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	t_filehandle file = 0;
	char filename[64];
	short path;
	long outtype;
	
	if (!s->s_name[0])
	{
		if (open_dialog(filename, &path, &outtype, 0L, 0))
		return;
	}
		
	else
	{
		strcpy(filename, s->s_name);
		if (locatefile_extended(filename, &path, &outtype, 0L, 0))
		{
			error("%s: can't find file \"%s\"", __EXTERNAL_NAME__, filename);
			return;
		}
	}

	if (path_opensysfile(filename, path, &file, READ_PERM))
	{
		error("%s: can't open file \"%s\"", __EXTERNAL_NAME__, filename);
		return;
	}

	read_from_file(x, file, filename);
	
	sysfile_close(file);
	
	if(!control_make_connection(x))
		control_update_monitor(x);
}

void read_from_file(t_control *x, t_filehandle file, char *filename)
{
	short i=0, err=0;
	char tag[64], rem[64];
		
	sysfile_setpos(file, SYSFILE_FROMSTART, 0); 

	do{	err = get_tag(file, tag, rem);
		
		if(	tag[0] != '?' &&
			tag[0] != '!' &&
			strcmp(tag, "ambiscore"))
			{
				error("%s: \"%s\" is no readable ambiscore file", __EXTERNAL_NAME__, filename);
				return;
			}
			
		else if(!strcmp(tag, "ambiscore"))
			err = read_ambiscore(x,file);

	} while(!err);
}

// parse data

short read_ambiscore(t_control *x, t_filehandle file)
{
	short err=0;
	char tag[64], rem[64];
	
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "trajectory"))
		{
			control_clear(x);
			err = read_trajectory(x,file);
		}
		
	} while(!err);
	
	return(err);
}

short read_trajectory(t_control *x, t_filehandle file)
{
	short err=0;
	char attr[64], val[64], tag[64], rem[64], index[64], data[64];
	short size;
	time_pos *pointer, *new_pointer;
	ambi coord[MAXPOINTS];
	
	// iterate though entries
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "loop"))
		{
			err = get_data(file, data);
			remove_space_from_string(data);
			x->loop = CLIP(string_to_number(data), 0, 2);
		}

		if(!strcmp(tag, "point"))
		{
		// create new breakpoint...	

			// allocate memory
			new_pointer = (time_pos *)sysmem_newptr(sizeof(time_pos));
			
			// read data
			err = read_breakpoint(file, new_pointer);

			// build linked list			
			if(!x->first_breakpoint || new_pointer->time > x->last_breakpoint->time)
				control_append_breakpoint(x, new_pointer);
			else
			{
				pointer = x->first_breakpoint;
				while(new_pointer->time > pointer->time)
				{
					pointer = pointer->next;
				}
				control_insert_breakpoint(x, new_pointer, pointer);
			}
	
			x->num_of_breakpoints++;
		}

		if(!strcmp(tag, "/trajectory"))
		{
			control_close(x);
			return(0);			
		}
		
	} while(!err);
	
	return(err);
}

short read_breakpoint(t_filehandle file, time_pos *breakpoint)
{
	short	err=0;
	short	format=0; // 0=aed  1=xyz
	char	data[64], tag[64], rem[64];
	
	breakpoint->position.x = breakpoint->position.y = breakpoint->position.z = 0; // default coordinates
	cartopol(&breakpoint->position);
		
	do{	err = get_tag(file, tag, rem);
		
		if(!strcmp(tag, "time"))
		{	err = get_data(file, data);
			remove_space_from_string(data);
			breakpoint->time = string_to_number(data);
		}
					
		if(!strcmp(tag, "xyz"))
		{	err = get_data(file, data);
			string_to_triplet(data, &breakpoint->position.x);
			cartopol(&breakpoint->position);
		}		

		if(!strcmp(tag, "aed"))
		{	err = get_data(file, data);
			string_to_triplet(data, &breakpoint->position.a);
			poltocar(&breakpoint->position);
		}		
		
		if(!strcmp(tag, "/point"))
			return(0);

	} while(!err);
	
	return(err);
}


//___________________________________________________________________________________________________________________________

// get tags, attributes and data from XML file

short get_tag(t_filehandle file, char *tag, char *rem)
{
	char buf;
	short err, i=0, end=64;
	
	do
	{if(file_getchar(file, &buf)) return(1);
	} while(buf != '<');
	
	if(file_getchar(file, &buf)) return(1);
	if(buf == '?')
	{
		tag[i++] = buf;
		do
		{if(file_getchar(file, &tag[i++])) return(1);
		} while (tag[i-1] != '>');
		
		tag[i-1] = '\0';
		rem[0] = '\0';
		return(0);
	}
	
	if(buf == '!')
	{
		tag[i++] = buf;
		do
		{if(file_getchar(file, &tag[i++])) return(1);
		} while (tag[i-1] != '>');
		
		tag[i-1] = '\0';
		rem[0] = '\0';
		return(0);
	}
	
	if(white_space(buf))
	{
		do
		{if(file_getchar(file, &buf)) return(1);
		} while(white_space(buf));
	}

	tag[i++] = buf;
	
	do
	{if(file_getchar(file, &tag[i++])) return(1);
	} while (! white_space(tag[i-1]) && tag[i-1] != '>' && i < end);
	
	if(tag[i-1] == '>')
	{
		tag[i-1] = '\0'; rem[0] = '\0';
		return(0);
	}

	tag[i-1] = '\0';
	
	do
	{if(file_getchar(file, &buf)) return(1);
	} while(white_space(buf));
	
	i=0;
	rem[i++] = buf;
	
	do
	{if(file_getchar(file, &rem[i++])) return(1);
	} while (rem[i-1] != '>' && i < end);
	
	rem[i-1] = '\0';
	return(0);
}

short get_data(t_filehandle file, char* data)
{
	short err=0, i=0;
	char buf;
	
	do
	{if(file_getchar(file, &data[i++])) return(1);
	} while(data[i-1] != '<');
	
	data[i-1] = '\0';
	
	return(err);
}

//___________________________________________________________________________________________________________________________

// utility functions

short file_getchar(t_filehandle file, char *c)
{
	long count = 1;
	short err;
	long pos, eof;
	
	err = sysfile_read(file, &count, c);
	
#ifdef WIN_VERSION
	sysfile_getpos(file, &pos);
	sysfile_geteof(file, &eof);
	if(pos == eof) err = 1;
#endif

	return err;
}

short white_space(char c)
{
	if(	c == 0x20 ||	// space
	 	c == 0x9  ||	// TAB
	 	c == 0xA  ||	// line feed
	 	c == 0xB  ||	// vertical tab
	 	c == 0xC  ||	// form feed
	 	c == 0xD )		// carriage return
		return(1);
	else return(0);
}

void remove_space_from_string(char *str)
{
	short i=0, j=0;
	
	do{	str[j] = str[i];
		if(! white_space(str[i])) j++;
		} while(str[i++] != '\0');
}	

short string_to_number(char *name)
{
	short i, j, x = 0;
	
	for(i=strlen(name), j=1;i>0;i--, j=j*10)
	{	x = x + (name[i-1] - 48) * j;
	}
	
	return(x);	
}

void string_to_triplet(char *string, double *coord_triplet)
// used for reading coordinate data triplets
{
	short i=0, j;
	double k;
	short sign;
	double value;

	for(j=0;j<3;j++)
	{
		value = 0; sign = 1; k = 0.1;
		while(white_space(string[i])) i++;
		
		if(string[i] == '-') {sign = -1;i++;}
	
		// string to float
		while(string[i] > 47 && string[i] < 58)
		{value = value * 10 + string[i++] - 48;
		}
	
		if(string[i] == '.')
		{
			i++;
			while(string[i] > 47 && string[i] < 58)
			{value = value + (string[i++] - 48) * k;
			k = k * 0.1;
			}
		}
		coord_triplet[j] = value * sign;
	}
}