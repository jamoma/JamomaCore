/* 

	ambicontrol.c	trajectory controller object for ambisonic sound spatialisation
					works in combination with "ambimonitor"
					part of the ICST Ambisonics Tools
					
	Copyright (C) 2003 - 2006 ICST Zurich / Philippe Kocher
	
	http://www.icst.net
		

	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
	
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.
	
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    
	2006/06/18 Version 1.1	minor bugfixes, ported to PC, treat all points added
	2006/03/27 Version 1.0	initial release


*/


#include "ambicontrol.h"
#include "fileIO.c"

#define __VERSION__ "1.1"

void *control_class;

//___________________________________________________________________________________________________________________________

// main function

void main(void)
{	
	setup((t_messlist **)&control_class, (method)control_new, (method)control_free,
					(short)sizeof(t_control), 0L, A_GIMME, 0);
	
	// animation
	addbang((method)control_bang);
	addint((method)control_int);
	addftx ((method)control_stepsize, 1);  
	addmess((method)control_start,	    	"start",		0);	
	addmess((method)control_stop,	    	"stop",			0);	
	addmess((method)control_interval,   	"interval", 	A_LONG,	0);

	// centre
	addmess((method)control_aed_input,		"aed",			A_GIMME, 0);	
	addmess((method)control_xyz_input,		"xyz",			A_GIMME, 0);
	addmess((method)control_centre_index,	"index",		A_LONG, 0);	

	// settings
	addmess((method)control_points,			"points",		A_GIMME, 0);	
	addmess((method)control_connect,		"connect",		A_DEFSYM, 0);	
	addmess((method)control_anything,		"anything",		A_GIMME, 0),

	// bounding box
	addmess((method)control_show_box,   	"show_box", 	A_LONG,	0);
	addmess((method)control_box,			"box",			A_GIMME, 0);	
	addmess((method)control_box_rgb,   		"box_rgb", 		A_GIMME,0);

	// stability (for random)
	addmess((method)control_stability,   	"stability", 	A_LONG,	0);

	// trajectory
	addmess((method)control_record,			"record",		A_GIMME, 0);
	addmess((method)control_close,			"close",		0);
	addmess((method)control_clear,			"clear",		0);
	addmess((method)control_loop,			"loop",			A_LONG, 0);
	addmess((method)control_time,			"time",			A_GIMME, 0);
	addmess((method)control_interpolation,	"interpolation",A_LONG, 0);
	addmess((method)control_fit_to_box,		"fit_to_box",	0);
	addmess((method)control_scale_to_box,	"scale_to_box",	0);
	
	addmess((method)control_write,			"write",		A_DEFSYM, 0);
	addmess((method)control_read,			"read",			A_DEFSYM, 0);

	// status report
	addmess((method)control_report,   		"report",		0);
	addmess((method)control_version,   		"version",		0);
	
	
	// methods for messages sent by Max
	addmess((method)control_assist,	  "assist",	  A_CANT, 0);
	
	post("ambicontrol    -    Philippe Kocher/ICST Zurich    -    � 2006");   
}

//___________________________________________________________________________________________________________________________

// object creation function

void *control_new(t_symbol *s, short ac, t_atom *av)
{
	t_control *x;
	short i,j,k;
	double buffer[3] = {0,0,0};
	
	x = (t_control *)newobject(control_class);
	

	// initialise values
	x->stepsize = 1;
	
	x->centre_index = 0;
	x->centre.a = x->centre.e = x->centre.d = 0;
	x->centre.x = x->centre.y = x->centre.z = 0;
	
	x->box_dimensions[0] = x->box_dimensions[1] = x->box_dimensions[2] = 2;
	x->box[0] = x->box[1] = x->box[2] = -1;
	x->box[3] = x->box[4] = x->box[5] = 1;
	x->box_color = BOX;

	x->show_box = x->show_graph = 0;
	x->update_box = x->update_graph = 0;
	
	x->box_pointer = &x->box[0];
	
	x->name = nil;
	strcpy(x->method_string, "nil");
	
	x->has_local_point = 0;
	x->all_points = 0;
	
	x->time_interval = 100;
	
	x->running = 0;
	
	x->recording = 0;
	x->first_breakpoint = 0;
	x->last_breakpoint = 0;
	x->num_of_breakpoints = 0;
	x->trajectory_duration = 0;
	
	x->trajectory_graph_handle = &x->trajectory_graph;
	
	x->time = 0;
	x->loop = 0;
	x->dir = 1;
	
	x->interp = x->interp_once = 0;
	
	// read arguments
	for(i=0,j=0,k=0;i<ac;i++)
	{
		switch (av[i].a_type)
		{
			case A_SYM:
			// a method
				strcpy(x->method_string, av[i].a_w.w_sym->s_name);
				break;
					
			case A_LONG:
			// the index of a point treated by this object
				if(j<MAXPOINTS && av[i].a_w.w_long > 0)
					x->points[j++] = av[i].a_w.w_long - 1;
				else if(av[i].a_w.w_long == 0)
					x->all_points = 1;
				break;
					
			case A_FLOAT:
			// the default coordinates of the local point
				if(k<3)
					buffer[k++] = av[i].a_w.w_float;
					x->has_local_point = 1;
				break;
		}
	}
		
	if(!x->all_points)
		x->count_points = j;
	
	x->local_point.x = buffer[0]; x->local_point.y = buffer[1]; x->local_point.z = buffer[2];
	cartopol(&x->local_point);
	
	// initialise inlets
	floatin(x, 1);

	// initialise outlets
	x->outlet = outlet_new(x, 0L);
	
	// initialise clocks
	x->animation_clock = clock_new(x,(method)control_bang);
	x->recording_clock = clock_new(x,(method)control_sample);

	return (x);
}

//___________________________________________________________________________________________________________________________

// animation

void control_start(t_control *x)
{
	control_int(x,1);
}

void control_stop(t_control *x)
{
	control_int(x,0);
}

void control_int(t_control *x, long n)
{
	x->running = n;

	// reset delta
	x->centre_delta.x = 0; x->centre_delta.y = 0; x->centre_delta.z = 0;
	x->centre_delta.a = 0; x->centre_delta.e = 0; x->centre_delta.d = 0;

	if(n) control_bang(x);
	else clock_unset(x->animation_clock);
}

void control_interval(t_control *x, long n)
{
	x->time_interval = (n > 1 ? n : 1);
}

void control_bang(t_control *x)
{	
	t_atom coords[4];
	short i, n;
				
	if(x->running) clock_delay(x->animation_clock, x->time_interval);  // schedule next clock tick...
	
	if(x->recording) return; // ...but do nothing while recording a trajectory

	if(x->has_local_point)
	{
		control_call_method(x, &x->local_point, 0);
		control_output_local_point(x);
	}
	
	if(control_make_connection(x)) return;		// check connection to monitor

	// iterate through points and apply method
	switch(x->all_points)
	{
		case 0:

			for(i=0;i<x->count_points;i++)
			{
				n = x->points[i];
				if(x->monitor->coord[n].status != 0)
				{
					control_call_method(x, &x->monitor->coord[n], i+1);
					mess1((void *)x->monitor,gensym("output_coord"), (void *)n);
				}
			}
			break;

		case 1:
		
			for(i=0;i<MAXPOINTS;i++)
			{
				if(x->monitor->coord[i].status != 0)
				{
					control_call_method(x, &x->monitor->coord[i], i+1);
					mess1((void *)x->monitor,gensym("output_coord"), (void *)i);
				}
			}
			break;
	}
	
	// increment time, if current method is "trajectory"

	if(! strcmp(x->method_string, "trajectory"))
	{
		x->time = x->time + x->time_interval * x->stepsize * x->dir;
		x->time = CLIP(x->time, 0, x->trajectory_duration);
	}

	if(x->stepsize) x->interp_once = 0;

	// reset delta
	x->centre_delta.x = 0; x->centre_delta.y = 0; x->centre_delta.z = 0;
	x->centre_delta.a = 0; x->centre_delta.e = 0; x->centre_delta.d = 0;
}

//___________________________________________________________________________________________________________________________

// METHODS

void control_call_method(t_control *x, ambi *coords, short index)
{
	if(! strcmp(x->method_string, "nil")) control_nil(x, coords);	
	else if(! strcmp(x->method_string, "rotate")) control_rotate(x, coords);	
	else if(! strcmp(x->method_string, "random")) control_random(x, coords, index);
	else if(! strcmp(x->method_string, "hrandom")) control_hrandom(x, coords, index);
	else if(! strcmp(x->method_string, "vrandom")) control_vrandom(x, coords, index);
	else if(! strcmp(x->method_string, "crandom")) control_crandom(x, coords, index);
	else if(! strcmp(x->method_string, "trajectory")) control_trajectory(x, coords);
//	...more to follow...
	else control_nil(x, coords);
}

void control_nil(t_control *x, ambi *coords)
{	
	// translation if centre has moved
	if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
	{
		coords->x = coords->x + x->centre_delta.x;
		coords->y = coords->y + x->centre_delta.y;
		coords->z = coords->z + x->centre_delta.z;
	}
	
	cartopol(coords);
}

void control_rotate(t_control *x, ambi *coords)
{	
	if(x->centre.d < 0.0001 && x->centre_delta.d == 0.)
	// simple rotation
	{
		coords->a = coords->a + x->stepsize;
			
		coords->a = (coords->a <  180 ? coords->a : coords->a - 360);
		coords->a = (coords->a > -180 ? coords->a : coords->a + 360);
		
		poltocar(coords);
	}
	else
	// complicated rotation
	{			
		// translation if centre has moved
		if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
		{
			coords->x = coords->x + x->centre_delta.x;
			coords->y = coords->y + x->centre_delta.y;
			coords->z = coords->z + x->centre_delta.z;
		}
			
		coords->x = coords->x - x->centre.x;
		coords->y = coords->y - x->centre.y;
			
		cartopol(coords);
		coords->a = coords->a + x->stepsize;
		poltocar(coords);

		coords->x = coords->x + x->centre.x;
		coords->y = coords->y + x->centre.y;
		
		cartopol(coords);
	}
}

void control_crandom(t_control *x, ambi *coords, short index)
{
	double term, stepsize;
			
	// generate new random numbers if necessary
	if(x->stability_point[index] < 0)
	{
		term = random();		
		term = (term > 0 ? 0.5+term*0.5 : -0.5+term*0.5);
		x->rand_point[index][3] = x->stepsize * term;
		
		x->stability_point[index] += x->stability;
	}
	else
	{
		x->stability_point[index] -= x->time_interval;
	}
	stepsize = x->stepsize;
	x->stepsize = x->rand_point[index][3];
	control_rotate(x,coords);
	x->stepsize = stepsize;
}

void control_hrandom(t_control *x, ambi *coords, short index)
{
	double term;

	// generate new random numbers if necessary
	if(x->stability_point[index] < 0)
	{
		term = random();
		x->rand_point[index][0] = x->stepsize * term * 0.01;	
		term = (term > 0 ? 1-term : -1-term);
		x->rand_point[index][1] = x->stepsize * term * 0.01;
		
		x->stability_point[index] += x->stability;
	}
	else
	{
		x->stability_point[index] -= x->time_interval;
	}
		
	// translation if centre has moved
	if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
	{
		coords->x = coords->x + x->centre_delta.x;
		coords->y = coords->y + x->centre_delta.y;
		coords->z = coords->z + x->centre_delta.z;
	}

	coords->x += x->rand_point[index][0];
	coords->y += x->rand_point[index][1];
	
	// mirror trajectory at box boundaries
	if(coords->x <= x->box[0] || coords->x >= x->box[3])
		x->rand_point[index][0] *= -1.;
	if(coords->y <= x->box[1] || coords->y >= x->box[4])
		x->rand_point[index][1] *= -1.;
			
	// clip to box
	coords->x = CLIP(coords->x, x->box[0], x->box[3]);
	coords->y = CLIP(coords->y, x->box[1], x->box[4]);
	
	cartopol(coords);
}

void control_vrandom(t_control *x, ambi *coords, short index)
{
	double term;
		
	// generate new random numbers if necessary
	if(x->stability_point[index] < 0)
	{
		term = random();
		term = (term > 0 ? 0.5+term*0.5 : -0.5+term*0.5);
		x->rand_point[index][2] = x->stepsize * term * 0.01;
		
		x->stability_point[index] += x->stability;
	}
	else
	{
		x->stability_point[index] -= x->time_interval;
	}	
	// translation if centre has moved
	if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
	{
		coords->x = coords->x + x->centre_delta.x;
		coords->y = coords->y + x->centre_delta.y;
		coords->z = coords->z + x->centre_delta.z;
	}

	coords->z += x->rand_point[index][2];
	
	// mirror trajectory at box boundaries
	if(coords->z <= x->box[2] || coords->z >= x->box[5])
		x->rand_point[index][2] *= -1.;
		
	// clip to box	
	coords->z = CLIP(coords->z, x->box[2], x->box[5]);
	
	cartopol(coords);
}

void control_random(t_control *x, ambi *coords, short index)
{
	double term;

			
	// generate new random numbers if necessary
	if(x->stability_point[index] < 0)
	{
		term = random();		
		x->rand_point[index][0] = x->stepsize * term * 0.01;
		term = (term > 0 ? 1-term : -1-term);
		x->rand_point[index][1] = x->stepsize * term * 0.01;
		term = (term > 0 ? 0.5+term*0.5 : -0.5+term*0.5);
		x->rand_point[index][2] = x->stepsize * term * 0.01;
		
		x->stability_point[index] += x->stability;
	}
	else
	{
		x->stability_point[index] -= x->time_interval;
	}
		
	// translation if centre has moved
	if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
	{
		coords->x = coords->x + x->centre_delta.x;
		coords->y = coords->y + x->centre_delta.y;
		coords->z = coords->z + x->centre_delta.z;
	}

	coords->x += x->rand_point[index][0];
	coords->y += x->rand_point[index][1];
	coords->z += x->rand_point[index][2];
			
	// mirror trajectory at box boundaries
	if(coords->x <= x->box[0] || coords->x >= x->box[3])
		x->rand_point[index][0] *= -1.;
	if(coords->y <= x->box[1] || coords->y >= x->box[4])
		x->rand_point[index][1] *= -1.;
	if(coords->z <= x->box[2] || coords->z >= x->box[5])
		x->rand_point[index][2] *= -1.;
			
	// clip to box
	coords->x = CLIP(coords->x, x->box[0], x->box[3]);
	coords->y = CLIP(coords->y, x->box[1], x->box[4]);
	coords->z = CLIP(coords->z, x->box[2], x->box[5]);
	
	cartopol(coords);
}

void control_trajectory(t_control *x, ambi *coords)
{		
	time_pos *pointer;
	long n = 0;
	
	if(!x->current_breakpoint) return; // no trajectory specified
	
	// translate trajectory if centre has moved
	if(x->centre_delta.x != 0 || x->centre_delta.y != 0 || x->centre_delta.z != 0)
	{
		pointer = x->first_breakpoint;
		while(pointer)
		{
			pointer->position.x += x->centre_delta.x;
			pointer->position.y += x->centre_delta.y;
			pointer->position.z += x->centre_delta.z;
	
		// update graphics
		sysmem_copyptr(&pointer->position, x->trajectory_graph+n,  sizeof(double) * 3);
		n += 3;
		
		pointer = pointer->next;
		}

	// reset delta here (translation of the trajectory only once per cycle)
	x->centre_delta.x = 0; x->centre_delta.y = 0; x->centre_delta.z = 0;
	x->centre_delta.a = 0; x->centre_delta.e = 0; x->centre_delta.d = 0;
	}

	if(!x->interp && !x->interp_once)
	{
		coords->a = x->current_breakpoint->position.a;
		coords->e = x->current_breakpoint->position.e;
		coords->d = x->current_breakpoint->position.d;

		coords->x = x->current_breakpoint->position.x;
		coords->y = x->current_breakpoint->position.y;
		coords->z = x->current_breakpoint->position.z;
	}

	if(x->interp_once)	// manual interpolation
	{
		control_calc_interpolation(x, coords, x->current_breakpoint, x->current_breakpoint->next);
		return;
	}
	
	if(x->stepsize * x->dir > 0)	// moving forward
	{	
		if((x->interp) && x->current_breakpoint->next)
			control_calc_interpolation(x, coords, x->current_breakpoint, x->current_breakpoint->next);

		if(x->current_breakpoint->next && x->time >= x->current_breakpoint->next->time)
		{
			while(x->current_breakpoint->next && x->time >= x->current_breakpoint->next->time)
			{
				x->current_breakpoint = x->current_breakpoint->next;
			}
		}
		if(!x->current_breakpoint->next) // hit the end
		{
			switch(x->loop)
			{
				case 0:
					return;
				case 1:
					x->time = 0;
					x->current_breakpoint = x->first_breakpoint;
					break;
				case 2:
					x->dir *= -1;
					break;
			}
		}
	}
	else if(x->dir * x->stepsize < 0)	// moving backward
	{
		if((x->interp) && x->current_breakpoint->prev)
			control_calc_interpolation(x, coords, x->current_breakpoint->prev, x->current_breakpoint);

		if(x->current_breakpoint->prev && x->time <= x->current_breakpoint->prev->time)
		{
			while(x->current_breakpoint->prev && x->time <= x->current_breakpoint->prev->time)
			{
				x->current_breakpoint = x->current_breakpoint->prev;
			}
		}
		if(!x->current_breakpoint->prev) // hit the beginning
		{
			switch(x->loop)
			{
				case 0:
					return;
				case 1:
					x->time = x->trajectory_duration;
					x->current_breakpoint = x->last_breakpoint;
					break;
				case 2:
					x->dir *= -1;
					break;
			}
		}
	}
	else	// no movement at all (stepsize = 0)
	{
		if(x->interp)
			control_calc_interpolation(x, coords, x->current_breakpoint, x->current_breakpoint->next);
			
		return;
	}

}

void control_calc_interpolation(t_control *x, ambi *coords, time_pos *point1, time_pos *point2)
{
	double azi_dist, interpol_factor;
	
	interpol_factor = (double)(x->time - point1->time) / (point2->time - point1->time);
	interpol_factor = CLIP(interpol_factor, 0, 1);
	
	if(x->interp <= 1)
 	{
		coords->x = point1->position.x +
			(point2->position.x - point1->position.x) * interpol_factor;
		coords->y = point1->position.y +
			(point2->position.y - point1->position.y) * interpol_factor;
		coords->z = point1->position.z +
			(point2->position.z - point1->position.z) * interpol_factor;
		
		cartopol(coords);		// xyz to aed
	}
	else
	{
		azi_dist = point2->position.a - point1->position.a;

		// find shortest distance
		azi_dist = (azi_dist >  180 ? azi_dist - 360 : azi_dist);
		azi_dist = (azi_dist < -180 ? azi_dist + 360 : azi_dist);
		
		coords->a = point1->position.a + azi_dist * interpol_factor;
		coords->e = point1->position.e +
			(point2->position.e - point1->position.e) * interpol_factor;
		coords->d = point1->position.d +
			(point2->position.d - point1->position.d) * interpol_factor;
		
		poltocar(coords);
	}
}

//___________________________________________________________________________________________________________________________

// manual interpolation in a trajectory

void control_time(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	if(!x->current_breakpoint) return;
	
	switch(av[0].a_type)
	{
		case A_LONG:
			x->time = CLIP(av[0].a_w.w_long, 0, x->trajectory_duration); break;
		case A_FLOAT:
			x->time = x->trajectory_duration * CLIP(av[0].a_w.w_float, 0, 1); break;
		default: x->time = 0;
	}
	
	if(x->time == x->trajectory_duration)
		x->current_breakpoint = x->last_breakpoint->prev;
	else
	{
		if(x->current_breakpoint == x->last_breakpoint)
			 x->current_breakpoint = x->last_breakpoint->prev;
		while(! (x->time >= x->current_breakpoint->time && x->time < x->current_breakpoint->next->time))
		{
			if(x->time < x->current_breakpoint->time)
				x->current_breakpoint = x->current_breakpoint->prev;
			else
				x->current_breakpoint = x->current_breakpoint->next;
		}
	}
	if(! strcmp(x->method_string, "trajectory") && ! x->running)
	{
		x->interp_once = 1;
		control_bang(x);
	}
}

//___________________________________________________________________________________________________________________________

// trajectory

void control_record(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	if(av[0].a_type == A_LONG && ac == 1)	// record a point in the monitor
	{
		control_clear(x);
		x->recording = 1;
		x->sampled_index = av[0].a_w.w_long - 1;
		
		x->start_time = -1;
		
		control_sample(x);
	}
	else	// record breakpoint input
	{
		control_clear(x);
		x->recording = 1;
	}

}

void control_close(t_control *x)
{
	time_pos *pointer;
	long n = 0;
	
	clock_unset(x->recording_clock);

	if(!x->num_of_breakpoints) return;
	
	x->recording = 0;
	x->first_breakpoint->time = 0;

	x->trajectory_duration = x->last_breakpoint->time;
	x->current_breakpoint = x->first_breakpoint;
	
	x->trajectory_graph = (double *)sysmem_newptr(sizeof(double) * 3 * x->num_of_breakpoints);
	x->trajectory_graph_handle = &x->trajectory_graph;
	
	x->time = 0;

	pointer = x->first_breakpoint;
	while(pointer)
	{
		sysmem_copyptr(&pointer->position, x->trajectory_graph+n, sizeof(double) * 3);
		n += 3;
		
		pointer = pointer->next;
	}

	if(!control_make_connection(x))
		control_update_monitor(x);
}

void control_clear(t_control *x)
{
	time_pos *pointer = x->first_breakpoint, *next_pointer;
	
	while(pointer)
	{	
		next_pointer = pointer->next;
		// free allocated memory
		sysmem_freeptr(pointer);
		
		pointer = next_pointer;
	}
	
	x->first_breakpoint = x->last_breakpoint = x->current_breakpoint = 0;

	x->recording = 0;
	clock_unset(x->recording_clock);

	x->num_of_breakpoints = 0;
	x->trajectory_duration = 0;
	
	sysmem_freeptr(x->trajectory_graph);
	x->trajectory_graph = 0;
	x->trajectory_graph_handle = &x->trajectory_graph;
	
	if(!control_make_connection(x))
		control_update_monitor(x);

}

void control_sample(t_control *x)
{	
	if(x->recording) clock_delay(x->recording_clock, x->time_interval);  // schedule next clock tick

	if(control_make_connection(x)) return;	// check connection to monitor
	
	if(x->start_time == -1 && x->monitor->coord[x->sampled_index].status == 1)
	{
		x->sampled_point = x->monitor->coord[x->sampled_index];			// get initial value
		x->start_time = 0;
	}
	
	if(x->monitor->coord[x->sampled_index].x != x->sampled_point.x ||	// point has been moved
		x->monitor->coord[x->sampled_index].y != x->sampled_point.y ||
		x->monitor->coord[x->sampled_index].z != x->sampled_point.z)
	{
		if(!x->start_time) x->start_time = gettime();					// reset clock if first movement
		control_record_breakpoint(x, gettime() - x->start_time, x->monitor->coord[x->sampled_index]);
		x->sampled_point = x->monitor->coord[x->sampled_index];
	}
}

void control_record_breakpoint(t_control *x, long time, ambi coords)
{
	time_pos *pointer, *new_pointer;
	
	time = (time < 0 ? 0 : time);
	
	// allocate memory
	new_pointer = (time_pos *)sysmem_newptr(sizeof(time_pos));

	new_pointer->time = time;
	sysmem_copyptr(&coords, &new_pointer->position, sizeof(double) * 6);		// copy all coordinates
	
	if(!x->first_breakpoint || time > x->last_breakpoint->time)
		control_append_breakpoint(x, new_pointer);
	else
	{
		pointer = x->first_breakpoint;
		while(time > pointer->time)
		{
			pointer = pointer->next;
		}
		control_insert_breakpoint(x, new_pointer, pointer);
	}
	
	x->num_of_breakpoints++;
}
	
void control_append_breakpoint(t_control *x, time_pos *new_pointer)
{
	if(!x->first_breakpoint)
		x->first_breakpoint = new_pointer;
	if(x->last_breakpoint)
		x->last_breakpoint->next = new_pointer;
	
	new_pointer->prev = x->last_breakpoint;
	new_pointer->next = 0;

	x->last_breakpoint = new_pointer;
}

void control_insert_breakpoint(t_control *x, time_pos *new_pointer, time_pos *insert_before)
{
	if(insert_before == x->first_breakpoint)
		x->first_breakpoint = new_pointer;
	else
		insert_before->prev->next = new_pointer;
	
	new_pointer->prev = insert_before->prev;
	new_pointer->next = insert_before;
	
	insert_before->prev = new_pointer;	
}

void control_loop(t_control *x, long n)
{
	x->loop = CLIP(n, 0, 2);
	if(x->loop != 2) x->dir = 1;
}

void control_interpolation(t_control *x, long n)
{
	x->interp = CLIP(n, 0, 2);
}

void control_fit_to_box(t_control *x)
{
	double max[3], min[3], centre[3];
	time_pos *pointer = x->first_breakpoint;
	double factor;
	short i, n=0;

	max[0] = max[1] = max[2] = -1.;
	min[0] = min[1] = min[2] = 1.;
	
	// find min and max
	while(pointer)
	{
		max[0] = (pointer->position.x > max[0] ? pointer->position.x : max[0]);
		max[1] = (pointer->position.y > max[1] ? pointer->position.y : max[1]);
		max[2] = (pointer->position.z > max[2] ? pointer->position.z : max[2]);

		min[0] = (pointer->position.x < min[0] ? pointer->position.x : min[0]);
		min[1] = (pointer->position.y < min[1] ? pointer->position.y : min[1]);
		min[2] = (pointer->position.z < min[2] ? pointer->position.z : min[2]);
		
		pointer = pointer->next;
	}
	
	for(i=0;i<3;i++)
		centre[i] = min[i] + (max[i] - min[i]) * 0.5;

	factor = x->box_dimensions[0] / (max[0] - min[0]);
	factor = (x->box_dimensions[1] / (max[1] - min[1]) < factor ? x->box_dimensions[1] / (max[1] - min[1]) : factor);
	factor = (x->box_dimensions[2] / (max[2] - min[2]) < factor ? x->box_dimensions[2] / (max[2] - min[2]) : factor);
		
	pointer = x->first_breakpoint;
	while(pointer)
	{
		// translate to origin
		pointer->position.x -= centre[0];
		pointer->position.y -= centre[1];
		pointer->position.z -= centre[2];
		
		// scale
		pointer->position.x *= factor;
		pointer->position.y *= factor;
		pointer->position.z *= factor;
		
		// translate to centre
		pointer->position.x += x->centre.x;
		pointer->position.y += x->centre.y;
		pointer->position.z += x->centre.z;
		
		cartopol(&pointer->position);
	
		// update graphics
		sysmem_copyptr(&pointer->position, x->trajectory_graph+n, sizeof(double) * 3);
		n += 3;
		
		pointer = pointer->next;
	}
	
	if(!control_make_connection(x))
		control_update_monitor(x);	
}

void control_scale_to_box(t_control *x)
{
	double max[3], min[3], centre[3];
	time_pos *pointer = x->first_breakpoint;
	double factor[3];
	short i, n=0;

	max[0] = max[1] = max[2] = -1.;
	min[0] = min[1] = min[2] = 1.;
	
	// find min and max
	while(pointer)
	{
		max[0] = (pointer->position.x > max[0] ? pointer->position.x : max[0]);
		max[1] = (pointer->position.y > max[1] ? pointer->position.y : max[1]);
		max[2] = (pointer->position.z > max[2] ? pointer->position.z : max[2]);

		min[0] = (pointer->position.x < min[0] ? pointer->position.x : min[0]);
		min[1] = (pointer->position.y < min[1] ? pointer->position.y : min[1]);
		min[2] = (pointer->position.z < min[2] ? pointer->position.z : min[2]);
		
		pointer = pointer->next;
	}
	
	for(i=0;i<3;i++)
		centre[i] = min[i] + (max[i] - min[i]) * 0.5;

	factor[0] = (max[0] - min[0] == 0 ? 1 : x->box_dimensions[0] / (max[0] - min[0]));
	factor[1] = (max[1] - min[1] == 0 ? 1 : x->box_dimensions[1] / (max[1] - min[1]));
	factor[2] = (max[2] - min[2] == 0 ? 1 : x->box_dimensions[2] / (max[2] - min[2]));
	
	pointer = x->first_breakpoint;
	while(pointer)
	{
		// translate to origin
		pointer->position.x -= centre[0];
		pointer->position.y -= centre[1];
		pointer->position.z -= centre[2];
		
		// scale
		pointer->position.x *= factor[0];
		pointer->position.y *= factor[1];
		pointer->position.z *= factor[2];
		
		// translate to centre
		pointer->position.x += x->centre.x;
		pointer->position.y += x->centre.y;
		pointer->position.z += x->centre.z;
		
		cartopol(&pointer->position);
	
		// update graphics
		sysmem_copyptr(&pointer->position, x->trajectory_graph+n,  sizeof(double) * 3);
		n += 3;
		
		pointer = pointer->next;
	}
	
	if(!control_make_connection(x))
		control_update_monitor(x);	
}

//___________________________________________________________________________________________________________________________

// centre

void control_centre_index(t_control *x, long n)
{
	x->centre_index = CLIP(n, 0, MAXPOINTS);	
}

void control_centre(t_control *x, ambi new_centre)
{
	ambi old_centre = x->centre;
	
	x->centre = new_centre;
	
	calc_delta(&x->centre_delta, &old_centre, &x->centre);
	control_calc_box(x);
	
	if(! x->running) control_bang(x);
	
	if(!control_make_connection(x))
		control_update_monitor(x);
}

//___________________________________________________________________________________________________________________________

// coordinate I/O

void control_aed_input(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	short i;
	double input[3] = {0, 0, 1};
	ambi coords;
	long time;
	
	if(av[0].a_type != A_LONG) return;
	if(av[0].a_w.w_long != x->centre_index && x->recording == 0) return;

	for(i=1;i<ac;i++)
	{
		switch(av[i].a_type)
		{
			case A_FLOAT : input[i-1] = av[i].a_w.w_float; break;
			case A_LONG: input[i-1] = av[i].a_w.w_long; break;
			default: input[i-1] = 0;
		}
	}
				
	coords.a = input[0];
	coords.e = input[1];
	coords.d = input[2];
	
	poltocar(&coords);
	
	if(x->recording)
	{
		time = av[0].a_w.w_long;
		control_record_breakpoint(x, time, coords);
	}
	else
		control_centre(x, coords);
}

void control_xyz_input(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	short i;
	double input[3] = {0, 0, 0};
	ambi coords;
	long time;
	
	if(av[0].a_type != A_LONG) return;
	if(av[0].a_w.w_long != x->centre_index && x->recording == 0) return;
	
	for(i=1;i<ac;i++)
	{
		switch(av[i].a_type)
		{
			case A_FLOAT : input[i-1] = av[i].a_w.w_float; break;
			case A_LONG: input[i-1] = av[i].a_w.w_long; break;
			default: input[i-1] = 0;
		}
	}
	
	coords.x = input[0];
	coords.y = input[1];
	coords.z = input[2];
	
	cartopol(&coords);
	
	if(x->recording)
	{
		time = av[0].a_w.w_long;
		control_record_breakpoint(x, time, coords);
	}
	else
		control_centre(x, coords);
}

void control_output_local_point(t_control *x)
{	
	t_atom out[4];
		
	SETLONG(&out[0], 0);					// index is always 0 (neutral/global)
	SETFLOAT(&out[1], x->local_point.a);
	SETFLOAT(&out[2], x->local_point.e);
	SETFLOAT(&out[3], x->local_point.d);
	
	outlet_anything(x->outlet,gensym("aed"),4,out);
}

//___________________________________________________________________________________________________________________________

// settings

void control_anything(t_control *x, t_symbol *s, short ac, t_atom *av)		// set controller's method
{
	if(! strcmp(s->s_name, "nil") ||
		! strcmp(s->s_name, "rotate") ||
		! strcmp(s->s_name, "random") ||
		! strcmp(s->s_name, "hrandom") ||
		! strcmp(s->s_name, "vrandom") ||
		! strcmp(s->s_name, "crandom") ||
		! strcmp(s->s_name, "trajectory"))
			strcpy(x->method_string, s->s_name);
	
	if(!strcmp(x->method_string, "trajectory") && !x->show_graph && x->show_box)
		x->show_graph = x->update_graph = 1;
		
	if(strcmp(x->method_string, "trajectory") && x->show_graph)
	{
		x->show_graph = 0;
		x->update_graph = 1;
	}
	
	if(!control_make_connection(x))
		control_update_monitor(x);
}

void control_stability(t_control *x, long n)
{
	short i;
	
	x->stability = n;
	
	for(i=0;i<x->count_points;i++)
		x->stability_point[i] = random() * x->stability;
}

void control_points(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	short i;
	
	x->all_points = 0;
	x->count_points = ac;
	for(i=0;i<ac;i++)
	{
		if(av[i].a_w.w_long > 0)
			x->points[i] = av[i].a_w.w_long - 1;
		else if(av[i].a_w.w_long == 0)
			x->all_points = 1;
	}
}

void control_box(t_control *x, t_symbol *s, short ac, t_atom *av)
{	
	short i;
	
	for(i=0;i<3;i++)
	{
		switch(av[i].a_type)
		{
			case A_FLOAT: x->box_dimensions[i] = av[i].a_w.w_float; break;
			case A_LONG:  x->box_dimensions[i] = av[i].a_w.w_long; break;
			default: x->box_dimensions[i] = 0.001;
		}
		x->box_dimensions[i] = (x->box_dimensions[i] > 0.001 ? x->box_dimensions[i] : 0.001);
	}
	
	control_calc_box(x);
	
	if(!control_make_connection(x))
		control_update_monitor(x);
}

void control_show_box(t_control *x, long n)
{
	n = CLIP(n, 0, 1);
	if(x->show_box == n) return;
	
	switch(n)
	{
		case 1: // new
			x->show_box = 1;
			x->update_box = 1;
			if(! strcmp(x->method_string, "trajectory"))
			{
				x->show_graph = 1;
				x->update_graph = 1;
			}
			break;

		case 0: // remove
			x->show_box = 0;
			x->update_box = 1;
			if(! strcmp(x->method_string, "trajectory"))
			{
				x->show_graph = 0;
				x->update_graph = 1;
			}

	}

	control_make_connection(x);
}

void control_box_rgb(t_control *x, t_symbol *s, short ac, t_atom *av)
{
	if(av[0].a_type == A_LONG) x->box_color.red = av[0].a_w.w_long * 255;
	else x->box_color.red = 0;
	if(av[1].a_type == A_LONG) x->box_color.green = av[1].a_w.w_long * 255;
	else x->box_color.green = 0;
	if(av[2].a_type == A_LONG) x->box_color.blue = av[2].a_w.w_long * 255;
	else x->box_color.blue = 0;
	
	if(!control_make_connection(x) && !x->running)
		control_update_monitor(x);
}

void control_stepsize(t_control *x, double f)
{
	short i;
	double term;
	
	x->stepsize = f;
	
	// calculate individual speeds for random methods
	for(i=0;i<x->count_points;i++)
	{
		term = random();		
		x->rand_point[i][0] = x->stepsize * term * 0.01;
		term = (term > 0 ? 1-term : -1-term);
		x->rand_point[i][1] = x->stepsize * term * 0.01;
		term = (term > 0 ? 0.5+term*0.5 : -0.5+term*0.5);
		x->rand_point[i][2] = x->stepsize * term * 0.01;
		x->rand_point[i][3] = x->stepsize * term;
	}
}

//___________________________________________________________________________________________________________________________

// connection to an ambimonitor

void control_connect(t_control *x, t_symbol *s)
{
	if(s != x->name) // a new monitor
	{
		if(x->show_box && !x->update_box)
		{
			control_box_remove(x);		// remove old box
			x->update_box = 1;
		}
		if(x->show_graph && !x->update_graph)
		{
			control_graph_remove(x);	// remove old graph
			x->update_graph = 1;
		}
	}
	x->name = s;
	control_make_connection(x);
}

short control_make_connection(t_control *x)
{
	// get pointer from the symbol "name"
	// in order to establish a connection to the ambimonitor object
	if(x->name == nil) return(1);
	if(!x->name->s_thing) return(1);

	x->monitor  = (t_monitor *)x->name->s_thing;
	
	if(x->update_box) // monitor not yet notified
	{
		if(x->show_box)
			control_box_new(x);
		else
			control_box_remove(x);
		x->update_box = 0;
	}
	
	if(x->update_graph) // monitor not yet notified
	{
		if(x->show_graph)
			control_graph_new(x);
		else
			control_graph_remove(x);
		x->update_graph = 0;
	}

	return(0);
}

// send messages to the connected ambimonitor

void control_box_new(t_control *x)
{
	mess4((void *)x->monitor,gensym("add_graph_new"),(void *)1,&x->box_color,&x->box_pointer,0);
	control_update_monitor(x);
}

void control_box_remove(t_control *x)
{
	mess1((void *)x->monitor,gensym("add_graph_remove"),&x->box_pointer);
	control_update_monitor(x);
}

void control_graph_new(t_control *x)
{
	mess4((void *)x->monitor,gensym("add_graph_new"),(void *)2,&x->box_color,x->trajectory_graph_handle,&x->num_of_breakpoints);
	control_update_monitor(x);
}

void control_graph_remove(t_control *x)
{
	mess1((void *)x->monitor,gensym("add_graph_remove"),x->trajectory_graph_handle);
	control_update_monitor(x);
}

// tell the connected ambimonitor to update itself

void control_update_monitor(t_control *x)
{
	mess0((void *)x->monitor,gensym("update_graphics"));
}

//___________________________________________________________________________________________________________________________

// mathematics

void cartopol(ambi *coords)		// xyz to aed
{
	coords->a = atan2(coords->x, coords->y) / PI * 180;
	coords->e = atan2(coords->z, pow(pow(coords->y,2)+pow(coords->x,2),0.5)) / PI * 180;
	coords->d = pow(pow(coords->x,2)+pow(coords->y,2)+pow(coords->z,2), 0.5) * 10;
}

void poltocar(ambi *coords)		// aed to xyz
{
	coords->x = cos((90 - coords->a) / 180 * PI) * cos(coords->e / 180 * PI) * coords->d * 0.1;
	coords->y = sin((90 - coords->a) / 180 * PI) * cos(coords->e / 180 * PI) * coords->d * 0.1;
	coords->z = sin(coords->e / 180 * PI) * coords->d * 0.1;
}

void calc_delta(ambi *delta, ambi *old_coords, ambi *new_coords)
{
	delta->x = delta->x + new_coords->x - old_coords->x;
	delta->y = delta->y + new_coords->y - old_coords->y;
	delta->z = delta->z + new_coords->z - old_coords->z;
	delta->a = delta->a + new_coords->a - old_coords->a;
	delta->e = delta->e + new_coords->e - old_coords->e;
	delta->d = delta->d + new_coords->d - old_coords->d;
}

void control_calc_box(t_control *x)
{
	x->box[0] = x->centre.x - x->box_dimensions[0] * 0.5;
	x->box[1] = x->centre.y - x->box_dimensions[1] * 0.5;
	x->box[2] = x->centre.z - x->box_dimensions[2] * 0.5;
	x->box[3] = x->centre.x + x->box_dimensions[0] * 0.5;
	x->box[4] = x->centre.y + x->box_dimensions[1] * 0.5;
	x->box[5] = x->centre.z + x->box_dimensions[2] * 0.5;
}

double random()
{
#ifdef MAC_VERSION
	return (double)Random() / RAND_MAX;
#else
	return (double)rand() / RAND_MAX * 2 -1;
#endif
}

//___________________________________________________________________________________________________________________________

// utilities

void control_assist(t_control *x, void *b, long m, long a, char *s)
{
	if (m == ASSIST_INLET) {
		switch (a) {	
		case 0:
			sprintf(s, "coordinates, messages");
			break;
		case 1:
			sprintf(s, "(float) stepsize");
		}
	}
	else
		sprintf(s, "aed coordinates of local point");
}

void control_version(void)
{
	post("ambicontrol    -    Philippe Kocher/ICST Zurich    -    � 2006");   
	post("    version %s compiled %s %s", __VERSION__, __DATE__, __TIME__);
}

void control_report(t_control *x)
{
	short i;
	t_atom temp;
	time_pos *pointer;
	
	post("ambicontrol");
	if(!control_make_connection(x))
	{
		SETSYM (&temp, x->name);
		post("    connected to ");
		postatom(&temp);
	}
	else post("    not connected");

	post("    method: %s", x->method_string);

	post("    treated points: ");
	for(i=0;i<x->count_points;i++)
	{
		SETLONG(&temp, x->points[i] + 1);
		postatom(&temp);
	}
	
	if(x->has_local_point)
		post("    local point: X %2.2f Y %2.2f Z %2.2f", x->local_point.x, x->local_point.y, x->local_point.z);
	post("    centre: X %2.2f Y %2.2f Z %2.2f", x->centre.x, x->centre.y, x->centre.z);
	post("    box: width %2.2f, depth %2.2f, height %2.2f", x->box_dimensions[0], x->box_dimensions[1], x->box_dimensions[2]);
	if(x->current_breakpoint)
	{
		post("    trajectory:");
		post("    %ld breakpoints, duration: %ld ms", x->num_of_breakpoints, x->trajectory_duration);
		pointer = x->first_breakpoint;
		while(pointer)
		{
			post("      time: %5ld \t x: %2.2f y: %2.2f z: %2.2f",
				pointer->time, pointer->position.x, pointer->position.y, pointer->position.z);
			pointer = pointer->next;
		}
	}
	else post("    no trajectory data");
}

void control_free(t_control *x)
{	
	control_clear(x);
	
	if(x->name != nil && x->name->s_thing && x->show_box) // connected and box shown
		control_box_remove(x);
	
	sysmem_freeptr(x->trajectory_graph_handle);
	freeobject((t_object *)x->animation_clock);
}